import asyncio
import logging
from typing import Dict, List, Optional, Any
from datetime import datetime, timedelta
from dataclasses import dataclass

from .jira_service import JiraService, JiraIssue
from .llm_service import LLMService, LLMConfig
from ..database.base import DatabaseInterface, JiraDocument

logger = logging.getLogger(__name__)

@dataclass
class RCAResult:
    bug_issue: JiraIssue
    similar_issues: List[Dict[str, Any]]
    analysis: str
    confidence_score: float
    recommended_actions: List[str]
    created_at: datetime

class RCAAgent:
    """Root Cause Analysis Agent for Jira bugs"""
    
    def __init__(
        self,
        jira_service: JiraService,
        llm_service: LLMService,
        database: DatabaseInterface,
        collection_name: str = "jira_stories",
        poll_interval: int = 300  # 5 minutes
    ):
        self.jira_service = jira_service
        self.llm_service = llm_service
        self.database = database
        self.collection_name = collection_name
        self.poll_interval = poll_interval
        self.running = False
        self.last_check = None
        
    async def initialize(self):
        """Initialize the RCA agent"""
        try:
            # Connect to database
            await self.database.connect()
            await self.database.create_collection(self.collection_name)
            
            # Test Jira connection
            if not await self.jira_service.test_connection():
                raise Exception("Failed to connect to Jira")
            
            # Initialize story collection if empty
            await self._initialize_story_collection()
            
            logger.info("RCA Agent initialized successfully")
        except Exception as e:
            logger.error(f"Failed to initialize RCA Agent: {e}")
            raise
    
    async def _initialize_story_collection(self):
        """Initialize the database with existing Jira stories"""
        try:
            # Get existing stories from Jira
            stories = await self.jira_service.get_story_issues(limit=1000)
            
            if stories:
                # Convert to JiraDocument format
                documents = []
                for story in stories:
                    # Generate embedding for the story
                    text_content = f"{story.title} {story.description}"
                    embedding = await self.llm_service.generate_embedding(text_content)
                    
                    doc = JiraDocument(
                        issue_id=story.key,
                        issue_title=story.title,
                        issue_description=story.description,
                        issue_categories=story.labels + story.components,
                        metadata={
                            "status": story.status,
                            "priority": story.priority,
                            "assignee": story.assignee,
                            "reporter": story.reporter,
                            "created": story.created.isoformat(),
                            "updated": story.updated.isoformat(),
                            "issue_type": story.issue_type
                        },
                        embedding=embedding
                    )
                    documents.append(doc)
                
                # Add to database
                success = await self.database.add_documents(self.collection_name, documents)
                if success:
                    logger.info(f"Initialized database with {len(documents)} stories")
                else:
                    logger.error("Failed to initialize story collection")
            else:
                logger.warning("No stories found to initialize collection")
                
        except Exception as e:
            logger.error(f"Error initializing story collection: {e}")
    
    async def start_monitoring(self):
        """Start monitoring Jira for new bugs"""
        self.running = True
        self.last_check = datetime.now() - timedelta(hours=1)  # Check last hour on start
        
        logger.info("Starting RCA Agent monitoring")
        
        while self.running:
            try:
                await self._check_for_new_bugs()
                await asyncio.sleep(self.poll_interval)
            except Exception as e:
                logger.error(f"Error during monitoring cycle: {e}")
                await asyncio.sleep(30)  # Short delay before retry
    
    def stop_monitoring(self):
        """Stop monitoring Jira"""
        self.running = False
        logger.info("Stopping RCA Agent monitoring")
    
    async def _check_for_new_bugs(self):
        """Check for new bug issues in Jira"""
        try:
            # Calculate time since last check
            hours_back = 1
            if self.last_check:
                time_diff = datetime.now() - self.last_check
                hours_back = max(1, int(time_diff.total_seconds() / 3600))
            
            # Get recent bugs
            recent_bugs = await self.jira_service.get_recent_bugs(hours=hours_back)
            
            if recent_bugs:
                logger.info(f"Found {len(recent_bugs)} recent bugs")
                
                for bug in recent_bugs:
                    try:
                        # Perform RCA for each bug
                        rca_result = await self.analyze_bug(bug)
                        
                        if rca_result:
                            # Process the result (could trigger notifications, create reports, etc.)
                            await self._process_rca_result(rca_result)
                        
                    except Exception as e:
                        logger.error(f"Error analyzing bug {bug.key}: {e}")
            
            self.last_check = datetime.now()
            
        except Exception as e:
            logger.error(f"Error checking for new bugs: {e}")
    
    async def analyze_bug(self, bug_issue: JiraIssue) -> Optional[RCAResult]:
        """Perform root cause analysis on a bug issue"""
        try:
            logger.info(f"Analyzing bug: {bug_issue.key}")
            
            # Create search query from bug details
            search_query = f"{bug_issue.title} {bug_issue.description}"
            
            # Perform semantic search for similar issues
            similar_issues = await self.database.semantic_search(
                collection_name=self.collection_name,
                query=search_query,
                limit=10
            )
            
            if not similar_issues:
                logger.warning(f"No similar issues found for bug {bug_issue.key}")
                return None
            
            # Use LLM to analyze similarity and generate insights
            analysis = await self.llm_service.analyze_similarity(
                bug_description=f"Title: {bug_issue.title}\nDescription: {bug_issue.description}",
                similar_issues=similar_issues
            )
            
            if not analysis:
                logger.error(f"Failed to generate analysis for bug {bug_issue.key}")
                return None
            
            # Extract recommended actions and confidence score
            recommended_actions = self._extract_recommended_actions(analysis)
            confidence_score = self._calculate_confidence_score(similar_issues, analysis)
            
            rca_result = RCAResult(
                bug_issue=bug_issue,
                similar_issues=similar_issues,
                analysis=analysis,
                confidence_score=confidence_score,
                recommended_actions=recommended_actions,
                created_at=datetime.now()
            )
            
            logger.info(f"Completed RCA for bug {bug_issue.key} with confidence {confidence_score}")
            return rca_result
            
        except Exception as e:
            logger.error(f"Error during RCA analysis for bug {bug_issue.key}: {e}")
            return None
    
    async def _process_rca_result(self, rca_result: RCAResult):
        """Process RCA result (add comments, create reports, etc.)"""
        try:
            # Add analysis as comment to the bug issue
            comment = f"""
## Automated Root Cause Analysis

**Confidence Level:** {rca_result.confidence_score:.2f}

**Similar Issues Found:** {len(rca_result.similar_issues)}

**Analysis:**
{rca_result.analysis}

**Recommended Actions:**
{chr(10).join([f"• {action}" for action in rca_result.recommended_actions])}

---
*Generated by RCA Agent at {rca_result.created_at.strftime('%Y-%m-%d %H:%M:%S')}*
            """
            
            success = await self.jira_service.add_comment(
                issue_key=rca_result.bug_issue.key,
                comment=comment
            )
            
            if success:
                logger.info(f"Added RCA comment to bug {rca_result.bug_issue.key}")
            else:
                logger.error(f"Failed to add RCA comment to bug {rca_result.bug_issue.key}")
            
            # Could also:
            # - Send notifications to teams
            # - Update issue priority based on analysis
            # - Create follow-up tasks
            # - Store results in reporting database
            
        except Exception as e:
            logger.error(f"Error processing RCA result for {rca_result.bug_issue.key}: {e}")
    
    def _extract_recommended_actions(self, analysis: str) -> List[str]:
        """Extract recommended actions from LLM analysis"""
        actions = []
        
        try:
            # Look for recommended actions section
            lines = analysis.split('\n')
            in_actions_section = False
            
            for line in lines:
                line = line.strip()
                if 'recommended actions' in line.lower():
                    in_actions_section = True
                    continue
                elif line.startswith('#') and in_actions_section:
                    # New section started
                    break
                elif in_actions_section and line:
                    # Clean up action text
                    action = line.lstrip('•-*').strip()
                    if action:
                        actions.append(action)
            
            # Fallback: extract any bullet points from the analysis
            if not actions:
                for line in lines:
                    line = line.strip()
                    if line.startswith(('•', '-', '*')) and len(line) > 5:
                        action = line.lstrip('•-*').strip()
                        actions.append(action)
            
        except Exception as e:
            logger.error(f"Error extracting recommended actions: {e}")
        
        return actions[:5]  # Limit to top 5 actions
    
    def _calculate_confidence_score(self, similar_issues: List[Dict], analysis: str) -> float:
        """Calculate confidence score based on similarity and analysis quality"""
        try:
            base_score = 0.5
            
            # Factor in number of similar issues found
            if len(similar_issues) >= 5:
                base_score += 0.2
            elif len(similar_issues) >= 3:
                base_score += 0.1
            
            # Factor in similarity scores if available
            if similar_issues and 'distance' in similar_issues[0]:
                avg_distance = sum(
                    issue.get('distance', 1.0) for issue in similar_issues[:3]
                ) / min(3, len(similar_issues))
                
                # Lower distance = higher similarity = higher confidence
                similarity_score = max(0, 1.0 - avg_distance)
                base_score += similarity_score * 0.3
            
            # Factor in analysis quality (basic heuristics)
            if analysis:
                analysis_lower = analysis.lower()
                quality_indicators = [
                    'root cause', 'pattern', 'similar', 'recommend',
                    'action', 'fix', 'solution', 'issue'
                ]
                
                indicator_count = sum(
                    1 for indicator in quality_indicators 
                    if indicator in analysis_lower
                )
                
                base_score += min(0.2, indicator_count * 0.03)
            
            return min(1.0, max(0.0, base_score))
            
        except Exception as e:
            logger.error(f"Error calculating confidence score: {e}")
            return 0.5
    
    async def update_story_collection(self, story_issues: List[JiraIssue] = None):
        """Update the story collection with new or updated stories"""
        try:
            if not story_issues:
                # Get recent stories if none provided
                story_issues = await self.jira_service.get_story_issues(limit=100)
            
            if not story_issues:
                logger.warning("No stories to update in collection")
                return
            
            documents = []
            for story in story_issues:
                # Check if story already exists
                existing_doc = await self.database.get_document(
                    self.collection_name, story.key
                )
                
                # Generate embedding
                text_content = f"{story.title} {story.description}"
                embedding = await self.llm_service.generate_embedding(text_content)
                
                doc = JiraDocument(
                    issue_id=story.key,
                    issue_title=story.title,
                    issue_description=story.description,
                    issue_categories=story.labels + story.components,
                    metadata={
                        "status": story.status,
                        "priority": story.priority,
                        "assignee": story.assignee,
                        "reporter": story.reporter,
                        "created": story.created.isoformat(),
                        "updated": story.updated.isoformat(),
                        "issue_type": story.issue_type
                    },
                    embedding=embedding
                )
                
                if existing_doc:
                    # Update existing document
                    await self.database.update_document(
                        self.collection_name, story.key, doc
                    )
                else:
                    # Add new document
                    documents.append(doc)
            
            # Add new documents in batch
            if documents:
                success = await self.database.add_documents(self.collection_name, documents)
                if success:
                    logger.info(f"Updated story collection with {len(documents)} new stories")
                else:
                    logger.error("Failed to update story collection")
            
        except Exception as e:
            logger.error(f"Error updating story collection: {e}")
    
    async def cleanup(self):
        """Cleanup resources"""
        try:
            self.stop_monitoring()
            await self.database.disconnect()
            await self.llm_service.close()
            logger.info("RCA Agent cleanup completed")
        except Exception as e:
            logger.error(f"Error during RCA Agent cleanup: {e}")
