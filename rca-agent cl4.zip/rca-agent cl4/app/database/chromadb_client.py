import chromadb
from chromadb.config import Settings
from typing import List, Dict, Any, Optional
import json
import logging
from .base import DatabaseInterface, JiraDocument

logger = logging.getLogger(__name__)

class ChromaDBClient(DatabaseInterface):
    """ChromaDB implementation for vector database operations"""
    
    def __init__(self, host: str = "localhost", port: int = 8000, persist_directory: str = "./chroma_db"):
        self.host = host
        self.port = port
        self.persist_directory = persist_directory
        self.client = None
        self.collections = {}
    
    async def connect(self) -> None:
        """Establish ChromaDB connection"""
        try:
            # For persistent storage
            self.client = chromadb.PersistentClient(path=self.persist_directory)
            logger.info(f"Connected to ChromaDB at {self.persist_directory}")
        except Exception as e:
            logger.error(f"Failed to connect to ChromaDB: {e}")
            raise
    
    async def disconnect(self) -> None:
        """Close ChromaDB connection"""
        if self.client:
            self.client = None
            self.collections = {}
            logger.info("Disconnected from ChromaDB")
    
    async def create_collection(self, collection_name: str) -> bool:
        """Create a new collection in ChromaDB"""
        try:
            if not self.client:
                await self.connect()
            
            collection = self.client.get_or_create_collection(
                name=collection_name,
                metadata={"description": "Jira issues collection for RCA analysis"}
            )
            self.collections[collection_name] = collection
            logger.info(f"Created/Retrieved collection: {collection_name}")
            return True
        except Exception as e:
            logger.error(f"Failed to create collection {collection_name}: {e}")
            return False
    
    async def add_documents(self, collection_name: str, documents: List[JiraDocument]) -> bool:
        """Add documents to ChromaDB collection"""
        try:
            if collection_name not in self.collections:
                await self.create_collection(collection_name)
            
            collection = self.collections[collection_name]
            
            # Prepare data for ChromaDB
            ids = [doc.issue_id for doc in documents]
            documents_text = [f"{doc.issue_title} {doc.issue_description}" for doc in documents]
            metadatas = [
                {
                    "issue_id": doc.issue_id,
                    "issue_title": doc.issue_title,
                    "issue_description": doc.issue_description,
                    "issue_categories": json.dumps(doc.issue_categories),
                    **doc.metadata
                }
                for doc in documents
            ]
            
            # Add embeddings if provided, otherwise ChromaDB will generate them
            if documents[0].embedding:
                embeddings = [doc.embedding for doc in documents]
                collection.add(
                    ids=ids,
                    documents=documents_text,
                    metadatas=metadatas,
                    embeddings=embeddings
                )
            else:
                collection.add(
                    ids=ids,
                    documents=documents_text,
                    metadatas=metadatas
                )
            
            logger.info(f"Added {len(documents)} documents to collection {collection_name}")
            return True
        except Exception as e:
            logger.error(f"Failed to add documents to {collection_name}: {e}")
            return False
    
    async def semantic_search(self, collection_name: str, query: str, limit: int = 10) -> List[Dict[str, Any]]:
        """Perform semantic search in ChromaDB"""
        try:
            if collection_name not in self.collections:
                await self.create_collection(collection_name)
            
            collection = self.collections[collection_name]
            results = collection.query(
                query_texts=[query],
                n_results=limit
            )
            
            # Format results
            formatted_results = []
            if results['documents'] and results['documents'][0]:
                for i, doc in enumerate(results['documents'][0]):
                    result = {
                        'id': results['ids'][0][i],
                        'document': doc,
                        'metadata': results['metadatas'][0][i],
                        'distance': results['distances'][0][i] if 'distances' in results else None
                    }
                    formatted_results.append(result)
            
            logger.info(f"Found {len(formatted_results)} results for query in {collection_name}")
            return formatted_results
        except Exception as e:
            logger.error(f"Failed to perform semantic search in {collection_name}: {e}")
            return []
    
    async def get_document(self, collection_name: str, document_id: str) -> Optional[JiraDocument]:
        """Retrieve a specific document from ChromaDB"""
        try:
            if collection_name not in self.collections:
                await self.create_collection(collection_name)
            
            collection = self.collections[collection_name]
            results = collection.get(ids=[document_id])
            
            if results['ids'] and results['ids'][0]:
                metadata = results['metadatas'][0]
                return JiraDocument(
                    issue_id=metadata['issue_id'],
                    issue_title=metadata['issue_title'],
                    issue_description=metadata['issue_description'],
                    issue_categories=json.loads(metadata['issue_categories']),
                    metadata={k: v for k, v in metadata.items() 
                             if k not in ['issue_id', 'issue_title', 'issue_description', 'issue_categories']}
                )
            return None
        except Exception as e:
            logger.error(f"Failed to get document {document_id} from {collection_name}: {e}")
            return None
    
    async def update_document(self, collection_name: str, document_id: str, document: JiraDocument) -> bool:
        """Update an existing document in ChromaDB"""
        try:
            if collection_name not in self.collections:
                await self.create_collection(collection_name)
            
            collection = self.collections[collection_name]
            
            metadata = {
                "issue_id": document.issue_id,
                "issue_title": document.issue_title,
                "issue_description": document.issue_description,
                "issue_categories": json.dumps(document.issue_categories),
                **document.metadata
            }
            
            document_text = f"{document.issue_title} {document.issue_description}"
            
            collection.update(
                ids=[document_id],
                documents=[document_text],
                metadatas=[metadata]
            )
            
            logger.info(f"Updated document {document_id} in collection {collection_name}")
            return True
        except Exception as e:
            logger.error(f"Failed to update document {document_id} in {collection_name}: {e}")
            return False
    
    async def delete_document(self, collection_name: str, document_id: str) -> bool:
        """Delete a document from ChromaDB"""
        try:
            if collection_name not in self.collections:
                await self.create_collection(collection_name)
            
            collection = self.collections[collection_name]
            collection.delete(ids=[document_id])
            
            logger.info(f"Deleted document {document_id} from collection {collection_name}")
            return True
        except Exception as e:
            logger.error(f"Failed to delete document {document_id} from {collection_name}: {e}")
            return False
