import asyncio
import logging
import sys
import json
from pathlib import Path
from datetime import datetime

# Add parent directory to path to import app modules
sys.path.append(str(Path(__file__).parent.parent))

from app.config import settings, DatabaseType
from app.database.chromadb_client import ChromaDBClient
from app.database.bigquery_client import BigQueryClient
from app.database.base import JiraDocument

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

async def export_data_to_json(source_db, collection_name: str, output_file: str):
    """Export data from database to JSON file"""
    logger.info(f"Exporting data from {collection_name} to {output_file}")
    
    try:
        await source_db.connect()
        
        # For ChromaDB, we need to query all documents
        # This is a simplified approach - in production you might need pagination
        results = await source_db.semantic_search(collection_name, "", limit=10000)
        
        exported_data = []
        for result in results:
            # Get full document data
            doc = await source_db.get_document(collection_name, result['id'])
            if doc:
                exported_data.append({
                    "issue_id": doc.issue_id,
                    "issue_title": doc.issue_title,
                    "issue_description": doc.issue_description,
                    "issue_categories": doc.issue_categories,
                    "metadata": doc.metadata,
                    "embedding": doc.embedding
                })
        
        # Write to JSON file
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump({
                "exported_at": datetime.now().isoformat(),
                "collection_name": collection_name,
                "document_count": len(exported_data),
                "documents": exported_data
            }, f, indent=2, ensure_ascii=False)
        
        logger.info(f"Exported {len(exported_data)} documents to {output_file}")
        return True
        
    except Exception as e:
        logger.error(f"Failed to export data: {e}")
        return False
    finally:
        await source_db.disconnect()

async def import_data_from_json(target_db, input_file: str, collection_name: str):
    """Import data from JSON file to database"""
    logger.info(f"Importing data from {input_file} to {collection_name}")
    
    try:
        # Read JSON file
        with open(input_file, 'r', encoding='utf-8') as f:
            data = json.load(f)
        
        documents_data = data.get("documents", [])
        if not documents_data:
            logger.warning("No documents found in JSON file")
            return True
        
        await target_db.connect()
        await target_db.create_collection(collection_name)
        
        # Convert to JiraDocument objects
        documents = []
        for doc_data in documents_data:
            doc = JiraDocument(
                issue_id=doc_data["issue_id"],
                issue_title=doc_data["issue_title"],
                issue_description=doc_data["issue_description"],
                issue_categories=doc_data["issue_categories"],
                metadata=doc_data["metadata"],
                embedding=doc_data.get("embedding")
            )
            documents.append(doc)
            
            # Process in batches
            if len(documents) >= 100:
                success = await target_db.add_documents(collection_name, documents)
                if not success:
                    logger.error("Failed to import document batch")
                    return False
                logger.info(f"Imported batch of {len(documents)} documents")
                documents = []
        
        # Import remaining documents
        if documents:
            success = await target_db.add_documents(collection_name, documents)
            if not success:
                logger.error("Failed to import final document batch")
                return False
            logger.info(f"Imported final batch of {len(documents)} documents")
        
        logger.info(f"Successfully imported {len(documents_data)} documents")
        return True
        
    except Exception as e:
        logger.error(f"Failed to import data: {e}")
        return False
    finally:
        await target_db.disconnect()

async def migrate_chromadb_to_bigquery():
    """Migrate data from ChromaDB to BigQuery"""
    logger.info("Migrating data from ChromaDB to BigQuery...")
    
    # Setup source and target databases
    source_db = ChromaDBClient(
        host=settings.chromadb_host,
        port=settings.chromadb_port,
        persist_directory=settings.chromadb_persist_directory
    )
    
    target_db = BigQueryClient(
        project_id=settings.bigquery_project_id,
        dataset_id=settings.bigquery_dataset_id
    )
    
    # Export to temporary JSON file
    temp_file = "temp_migration_data.json"
    
    try:
        # Export from ChromaDB
        success = await export_data_to_json(source_db, settings.agent_collection_name, temp_file)
        if not success:
            return False
        
        # Import to BigQuery
        success = await import_data_from_json(target_db, temp_file, settings.agent_collection_name)
        if not success:
            return False
        
        # Clean up temp file
        Path(temp_file).unlink()
        
        logger.info("Migration completed successfully!")
        return True
        
    except Exception as e:
        logger.error(f"Migration failed: {e}")
        return False

async def migrate_bigquery_to_chromadb():
    """Migrate data from BigQuery to ChromaDB"""
    logger.info("Migrating data from BigQuery to ChromaDB...")
    
    # Setup source and target databases
    source_db = BigQueryClient(
        project_id=settings.bigquery_project_id,
        dataset_id=settings.bigquery_dataset_id
    )
    
    target_db = ChromaDBClient(
        host=settings.chromadb_host,
        port=settings.chromadb_port,
        persist_directory=settings.chromadb_persist_directory
    )
    
    # Export to temporary JSON file
    temp_file = "temp_migration_data.json"
    
    try:
        # Export from BigQuery
        success = await export_data_to_json(source_db, settings.agent_collection_name, temp_file)
        if not success:
            return False
        
        # Import to ChromaDB
        success = await import_data_from_json(target_db, temp_file, settings.agent_collection_name)
        if not success:
            return False
        
        # Clean up temp file
        Path(temp_file).unlink()
        
        logger.info("Migration completed successfully!")
        return True
        
    except Exception as e:
        logger.error(f"Migration failed: {e}")
        return False

async def backup_data():
    """Create a backup of the current database"""
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    backup_file = f"rca_agent_backup_{timestamp}.json"
    
    logger.info(f"Creating backup: {backup_file}")
    
    # Setup database based on current configuration
    if settings.database_type == DatabaseType.CHROMADB:
        database = ChromaDBClient(
            host=settings.chromadb_host,
            port=settings.chromadb_port,
            persist_directory=settings.chromadb_persist_directory
        )
    else:
        database = BigQueryClient(
            project_id=settings.bigquery_project_id,
            dataset_id=settings.bigquery_dataset_id
        )
    
    success = await export_data_to_json(database, settings.agent_collection_name, backup_file)
    
    if success:
        logger.info(f"Backup created successfully: {backup_file}")
    else:
        logger.error("Backup failed")
    
    return success

async def restore_data(backup_file: str):
    """Restore data from a backup file"""
    logger.info(f"Restoring data from backup: {backup_file}")
    
    if not Path(backup_file).exists():
        logger.error(f"Backup file not found: {backup_file}")
        return False
    
    # Setup database based on current configuration
    if settings.database_type == DatabaseType.CHROMADB:
        database = ChromaDBClient(
            host=settings.chromadb_host,
            port=settings.chromadb_port,
            persist_directory=settings.chromadb_persist_directory
        )
    else:
        database = BigQueryClient(
            project_id=settings.bigquery_project_id,
            dataset_id=settings.bigquery_dataset_id
        )
    
    success = await import_data_from_json(database, backup_file, settings.agent_collection_name)
    
    if success:
        logger.info("Data restored successfully")
    else:
        logger.error("Restore failed")
    
    return success

async def main():
    """Main migration function"""
    print("RCA Agent Data Migration Tool")
    print("============================")
    print("1. Migrate ChromaDB to BigQuery")
    print("2. Migrate BigQuery to ChromaDB")
    print("3. Create backup")
    print("4. Restore from backup")
    print("5. Exit")
    
    choice = input("\nSelect an option (1-5): ").strip()
    
    if choice == "1":
        success = await migrate_chromadb_to_bigquery()
    elif choice == "2":
        success = await migrate_bigquery_to_chromadb()
    elif choice == "3":
        success = await backup_data()
    elif choice == "4":
        backup_file = input("Enter backup file path: ").strip()
        success = await restore_data(backup_file)
    elif choice == "5":
        logger.info("Exiting...")
        sys.exit(0)
    else:
        logger.error("Invalid option selected")
        sys.exit(1)
    
    if success:
        logger.info("Operation completed successfully!")
    else:
        logger.error("Operation failed!")
        sys.exit(1)

if __name__ == "__main__":
    asyncio.run(main())