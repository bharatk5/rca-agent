import openai
import anthropic
import logging
from typing import Dict, List, Optional, Any
from enum import Enum
from dataclasses import dataclass

logger = logging.getLogger(__name__)

class LLMProvider(Enum):
    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    OLLAMA = "ollama"

@dataclass
class LLMConfig:
    provider: LLMProvider
    model: str
    api_key: Optional[str] = None
    base_url: Optional[str] = None
    temperature: float = 0.7
    max_tokens: int = 1000

class LLMService:
    """Configurable LLM service for various providers"""
    
    def __init__(self, config: LLMConfig):
        self.config = config
        self.client = None
        self._initialize_client()
    
    def _initialize_client(self):
        """Initialize the appropriate LLM client"""
        try:
            if self.config.provider == LLMProvider.OPENAI:
                self.client = openai.AsyncOpenAI(
                    api_key=self.config.api_key,
                    base_url=self.config.base_url
                )
            elif self.config.provider == LLMProvider.ANTHROPIC:
                self.client = anthropic.AsyncAnthropic(
                    api_key=self.config.api_key
                )
            elif self.config.provider == LLMProvider.OLLAMA:
                # For Ollama, we'll use aiohttp directly
                import aiohttp
                self.session = aiohttp.ClientSession()
            
            logger.info(f"Initialized {self.config.provider.value} client")
        except Exception as e:
            logger.error(f"Failed to initialize LLM client: {e}")
            raise
    
    async def generate_response(self, prompt: str, system_prompt: str = None) -> Optional[str]:
        """Generate response from LLM"""
        try:
            if self.config.provider == LLMProvider.OPENAI:
                return await self._openai_generate(prompt, system_prompt)
            elif self.config.provider == LLMProvider.ANTHROPIC:
                return await self._anthropic_generate(prompt, system_prompt)
            elif self.config.provider == LLMProvider.OLLAMA:
                return await self._ollama_generate(prompt, system_prompt)
            else:
                raise ValueError(f"Unsupported LLM provider: {self.config.provider}")
        except Exception as e:
            logger.error(f"Error generating LLM response: {e}")
            return None
    
    async def _openai_generate(self, prompt: str, system_prompt: str = None) -> str:
        """Generate response using OpenAI API"""
        messages = []
        
        if system_prompt:
            messages.append({"role": "system", "content": system_prompt})
        
        messages.append({"role": "user", "content": prompt})
        
        response = await self.client.chat.completions.create(
            model=self.config.model,
            messages=messages,
            temperature=self.config.temperature,
            max_tokens=self.config.max_tokens
        )
        
        return response.choices[0].message.content
    
    async def _anthropic_generate(self, prompt: str, system_prompt: str = None) -> str:
        """Generate response using Anthropic API"""
        response = await self.client.messages.create(
            model=self.config.model,
            max_tokens=self.config.max_tokens,
            temperature=self.config.temperature,
            system=system_prompt or "",
            messages=[
                {"role": "user", "content": prompt}
            ]
        )
        
        return response.content[0].text
    
    async def _ollama_generate(self, prompt: str, system_prompt: str = None) -> str:
        """Generate response using Ollama API"""
        url = f"{self.config.base_url or 'http://localhost:11434'}/api/generate"
        
        payload = {
            "model": self.config.model,
            "prompt": prompt,
            "system": system_prompt or "",
            "stream": False,
            "options": {
                "temperature": self.config.temperature,
                "num_predict": self.config.max_tokens
            }
        }
        
        async with self.session.post(url, json=payload) as response:
            if response.status == 200:
                data = await response.json()
                return data.get("response", "")
            else:
                raise Exception(f"Ollama API error: {response.status}")
    
    async def generate_embedding(self, text: str) -> Optional[List[float]]:
        """Generate embeddings for text"""
        try:
            if self.config.provider == LLMProvider.OPENAI:
                response = await self.client.embeddings.create(
                    model="text-embedding-ada-002",
                    input=text
                )
                return response.data[0].embedding
            else:
                # For other providers, you might need to use sentence-transformers
                # or other embedding models
                logger.warning(f"Embedding generation not implemented for {self.config.provider}")
                return None
        except Exception as e:
            logger.error(f"Error generating embedding: {e}")
            return None
    
    async def analyze_similarity(self, bug_description: str, similar_issues: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Analyze similarity between bug and potential related stories"""
        system_prompt = """
        You are an expert software engineer performing root cause analysis. 
        Analyze the given bug and similar issues to identify potential root causes and patterns.
        
        Focus on:
        1. Common themes or patterns
        2. Potential root causes
        3. Recommended actions
        4. Confidence level of your analysis
        
        Provide a structured response with actionable insights.
        """
        
        similar_issues_text = "\n\n".join([
            f"Issue {i+1}: {issue.get('metadata', {}).get('issue_title', 'N/A')}\n"
            f"Description: {issue.get('metadata', {}).get('issue_description', 'N/A')}"
            for i, issue in enumerate(similar_issues[:5])  # Limit to top 5
        ])
        
        prompt = f"""
        Bug to analyze:
        {bug_description}
        
        Similar issues found:
        {similar_issues_text}
        
        Please provide your analysis in the following format:
        
        ## Root Cause Analysis
        
        ### Patterns Identified:
        [List common patterns or themes]
        
        ### Potential Root Causes:
        [List potential root causes with reasoning]
        
        ### Recommended Actions:
        [List specific actionable recommendations]
        
        ### Confidence Level:
        [High/Medium/Low with explanation]
        """
        
        return await self.generate_response(prompt, system_prompt)
    
    async def close(self):
        """Close LLM service connections"""
        if hasattr(self, 'session') and self.session:
            await self.session.close()