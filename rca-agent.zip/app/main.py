from app.agent import RCAAgent
from utils.jira_utils import JiraClient, JiraConfig
from utils.chroma_db_utils import ChromaDBUtility

jira_config = JiraConfig()
jira_client = JiraClient(config=jira_config)
chroma_db = ChromaDBUtility(collection_name="jira_issues")

agent = RCAAgent(db=chroma_db, jira=jira_client)
results = agent.process_new_bugs()

for bug_id, matches in results.items():
    print(f"\nBug: {bug_id}")
    for match in matches:
        print(f"→ {match['metadata']['title']}")
