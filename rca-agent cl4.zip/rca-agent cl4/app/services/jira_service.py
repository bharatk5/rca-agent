import aiohttp
import asyncio
import json
import logging
from typing import Dict, List, Optional, Any
from dataclasses import dataclass
from datetime import datetime
import base64

logger = logging.getLogger(__name__)

@dataclass
class JiraIssue:
    id: str
    key: str
    title: str
    description: str
    status: str
    issue_type: str
    priority: str
    assignee: Optional[str]
    reporter: str
    created: datetime
    updated: datetime
    labels: List[str]
    components: List[str]
    custom_fields: Dict[str, Any]

@dataclass
class JiraStoryRequest:
    project_key: str
    summary: str
    description: str
    issue_type: str = "Story"
    priority: str = "Medium"
    assignee: Optional[str] = None
    labels: List[str] = None
    components: List[str] = None
    custom_fields: Dict[str, Any] = None

class JiraService:
    """Service for Jira CRUD operations"""
    
    def __init__(self, base_url: str, username: str, api_token: str):
        self.base_url = base_url.rstrip('/')
        self.username = username
        self.api_token = api_token
        self.session = None
        self._auth_header = self._create_auth_header()
    
    def _create_auth_header(self) -> str:
        """Create basic auth header for Jira API"""
        auth_string = f"{self.username}:{self.api_token}"
        auth_bytes = auth_string.encode('ascii')
        auth_b64 = base64.b64encode(auth_bytes).decode('ascii')
        return f"Basic {auth_b64}"
    
    async def __aenter__(self):
        """Async context manager entry"""
        self.session = aiohttp.ClientSession(
            headers={
                "Authorization": self._auth_header,
                "Content-Type": "application/json",
                "Accept": "application/json"
            }
        )
        return self
    
    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit"""
        if self.session:
            await self.session.close()
    
    async def test_connection(self) -> bool:
        """Test Jira API connection"""
        try:
            if not self.session:
                self.session = aiohttp.ClientSession(
                    headers={
                        "Authorization": self._auth_header,
                        "Content-Type": "application/json",
                        "Accept": "application/json"
                    }
                )
            
            url = f"{self.base_url}/rest/api/3/myself"
            async with self.session.get(url) as response:
                if response.status == 200:
                    logger.info("Jira connection test successful")
                    return True
                else:
                    logger.error(f"Jira connection test failed: {response.status}")
                    return False
        except Exception as e:
            logger.error(f"Jira connection test error: {e}")
            return False
    
    async def get_issue(self, issue_key: str) -> Optional[JiraIssue]:
        """Get a specific Jira issue by key"""
        try:
            url = f"{self.base_url}/rest/api/3/issue/{issue_key}"
            params = {
                "expand": "names,renderedFields"
            }
            
            async with self.session.get(url, params=params) as response:
                if response.status == 200:
                    data = await response.json()
                    return self._parse_jira_issue(data)
                elif response.status == 404:
                    logger.warning(f"Issue {issue_key} not found")
                    return None
                else:
                    logger.error(f"Failed to get issue {issue_key}: {response.status}")
                    return None
        except Exception as e:
            logger.error(f"Error getting issue {issue_key}: {e}")
            return None
    
    async def search_issues(self, jql: str, max_results: int = 50) -> List[JiraIssue]:
        """Search for Jira issues using JQL"""
        try:
            url = f"{self.base_url}/rest/api/3/search"
            payload = {
                "jql": jql,
                "maxResults": max_results,
                "expand": ["names", "renderedFields"],
                "fields": ["*all"]
            }
            
            async with self.session.post(url, json=payload) as response:
                if response.status == 200:
                    data = await response.json()
                    issues = []
                    for issue_data in data.get("issues", []):
                        parsed_issue = self._parse_jira_issue(issue_data)
                        if parsed_issue:
                            issues.append(parsed_issue)
                    
                    logger.info(f"Found {len(issues)} issues for JQL: {jql}")
                    return issues
                else:
                    logger.error(f"Failed to search issues: {response.status}")
                    return []
        except Exception as e:
            logger.error(f"Error searching issues: {e}")
            return []
    
    async def get_recent_bugs(self, project_key: str = None, hours: int = 24) -> List[JiraIssue]:
        """Get recent bug issues"""
        jql_parts = [
            "type = Bug",
            f"created >= -{hours}h"
        ]
        
        if project_key:
            jql_parts.append(f"project = {project_key}")
        
        jql = " AND ".join(jql_parts)
        jql += " ORDER BY created DESC"
        
        return await self.search_issues(jql)
    
    async def get_story_issues(self, project_key: str = None, limit: int = 1000) -> List[JiraIssue]:
        """Get story issues for semantic search database"""
        jql_parts = [
            "type = Story"
        ]
        
        if project_key:
            jql_parts.append(f"project = {project_key}")
        
        jql = " AND ".join(jql_parts)
        jql += " ORDER BY created DESC"
        
        return await self.search_issues(jql, max_results=limit)
    
    async def create_story(self, story_request: JiraStoryRequest) -> Optional[str]:
        """Create a new Jira story"""
        try:
            url = f"{self.base_url}/rest/api/3/issue"
            
            # Build the issue payload
            fields = {
                "project": {"key": story_request.project_key},
                "summary": story_request.summary,
                "description": {
                    "type": "doc",
                    "version": 1,
                    "content": [
                        {
                            "type": "paragraph",
                            "content": [
                                {
                                    "type": "text",
                                    "text": story_request.description
                                }
                            ]
                        }
                    ]
                },
                "issuetype": {"name": story_request.issue_type},
                "priority": {"name": story_request.priority}
            }
            
            # Add assignee if provided
            if story_request.assignee:
                fields["assignee"] = {"accountId": story_request.assignee}
            
            # Add labels if provided
            if story_request.labels:
                fields["labels"] = story_request.labels
            
            # Add components if provided
            if story_request.components:
                fields["components"] = [{"name": comp} for comp in story_request.components]
            
            # Add custom fields if provided
            if story_request.custom_fields:
                fields.update(story_request.custom_fields)
            
            payload = {"fields": fields}
            
            async with self.session.post(url, json=payload) as response:
                if response.status == 201:
                    data = await response.json()
                    issue_key = data.get("key")
                    logger.info(f"Created story: {issue_key}")
                    return issue_key
                else:
                    error_text = await response.text()
                    logger.error(f"Failed to create story: {response.status} - {error_text}")
                    return None
        except Exception as e:
            logger.error(f"Error creating story: {e}")
            return None
    
    async def update_story(self, issue_key: str, update_data: Dict[str, Any]) -> bool:
        """Update an existing Jira story"""
        try:
            url = f"{self.base_url}/rest/api/3/issue/{issue_key}"
            
            # Build update payload
            fields = {}
            if "summary" in update_data:
                fields["summary"] = update_data["summary"]
            
            if "description" in update_data:
                fields["description"] = {
                    "type": "doc",
                    "version": 1,
                    "content": [
                        {
                            "type": "paragraph",
                            "content": [
                                {
                                    "type": "text",
                                    "text": update_data["description"]
                                }
                            ]
                        }
                    ]
                }
            
            if "priority" in update_data:
                fields["priority"] = {"name": update_data["priority"]}
            
            if "assignee" in update_data:
                fields["assignee"] = {"accountId": update_data["assignee"]}
            
            if "labels" in update_data:
                fields["labels"] = update_data["labels"]
            
            if "components" in update_data:
                fields["components"] = [{"name": comp} for comp in update_data["components"]]
            
            payload = {"fields": fields}
            
            async with self.session.put(url, json=payload) as response:
                if response.status == 204:
                    logger.info(f"Updated story: {issue_key}")
                    return True
                else:
                    error_text = await response.text()
                    logger.error(f"Failed to update story {issue_key}: {response.status} - {error_text}")
                    return False
        except Exception as e:
            logger.error(f"Error updating story {issue_key}: {e}")
            return False
    
    async def delete_story(self, issue_key: str) -> bool:
        """Delete a Jira story"""
        try:
            url = f"{self.base_url}/rest/api/3/issue/{issue_key}"
            
            async with self.session.delete(url) as response:
                if response.status == 204:
                    logger.info(f"Deleted story: {issue_key}")
                    return True
                else:
                    error_text = await response.text()
                    logger.error(f"Failed to delete story {issue_key}: {response.status} - {error_text}")
                    return False
        except Exception as e:
            logger.error(f"Error deleting story {issue_key}: {e}")
            return False
    
    async def transition_issue(self, issue_key: str, transition_id: str, comment: str = None) -> bool:
        """Transition an issue to a different status"""
        try:
            url = f"{self.base_url}/rest/api/3/issue/{issue_key}/transitions"
            
            payload = {
                "transition": {"id": transition_id}
            }
            
            if comment:
                payload["update"] = {
                    "comment": [
                        {
                            "add": {
                                "body": {
                                    "type": "doc",
                                    "version": 1,
                                    "content": [
                                        {
                                            "type": "paragraph",
                                            "content": [
                                                {
                                                    "type": "text",
                                                    "text": comment
                                                }
                                            ]
                                        }
                                    ]
                                }
                            }
                        }
                    ]
                }
            
            async with self.session.post(url, json=payload) as response:
                if response.status == 204:
                    logger.info(f"Transitioned issue {issue_key} with transition {transition_id}")
                    return True
                else:
                    error_text = await response.text()
                    logger.error(f"Failed to transition issue {issue_key}: {response.status} - {error_text}")
                    return False
        except Exception as e:
            logger.error(f"Error transitioning issue {issue_key}: {e}")
            return False
    
    async def get_available_transitions(self, issue_key: str) -> List[Dict[str, Any]]:
        """Get available transitions for an issue"""
        try:
            url = f"{self.base_url}/rest/api/3/issue/{issue_key}/transitions"
            
            async with self.session.get(url) as response:
                if response.status == 200:
                    data = await response.json()
                    return data.get("transitions", [])
                else:
                    logger.error(f"Failed to get transitions for {issue_key}: {response.status}")
                    return []
        except Exception as e:
            logger.error(f"Error getting transitions for {issue_key}: {e}")
            return []
    
    async def add_comment(self, issue_key: str, comment: str) -> bool:
        """Add a comment to an issue"""
        try:
            url = f"{self.base_url}/rest/api/3/issue/{issue_key}/comment"
            
            payload = {
                "body": {
                    "type": "doc",
                    "version": 1,
                    "content": [
                        {
                            "type": "paragraph",
                            "content": [
                                {
                                    "type": "text",
                                    "text": comment
                                }
                            ]
                        }
                    ]
                }
            }
            
            async with self.session.post(url, json=payload) as response:
                if response.status == 201:
                    logger.info(f"Added comment to issue {issue_key}")
                    return True
                else:
                    error_text = await response.text()
                    logger.error(f"Failed to add comment to {issue_key}: {response.status} - {error_text}")
                    return False
        except Exception as e:
            logger.error(f"Error adding comment to {issue_key}: {e}")
            return False
    
    def _parse_jira_issue(self, issue_data: Dict[str, Any]) -> Optional[JiraIssue]:
        """Parse Jira API response into JiraIssue object"""
        try:
            fields = issue_data.get("fields", {})
            
            # Extract description text from Atlassian Document Format
            description = self._extract_description_text(fields.get("description"))
            
            # Parse dates
            created = datetime.fromisoformat(fields.get("created", "").replace("Z", "+00:00"))
            updated = datetime.fromisoformat(fields.get("updated", "").replace("Z", "+00:00"))
            
            # Extract assignee
            assignee = None
            if fields.get("assignee"):
                assignee = fields["assignee"].get("displayName")
            
            # Extract reporter
            reporter = fields.get("reporter", {}).get("displayName", "Unknown")
            
            # Extract labels and components
            labels = fields.get("labels", [])
            components = [comp.get("name", "") for comp in fields.get("components", [])]
            
            # Extract custom fields (excluding standard fields)
            standard_fields = {
                "summary", "description", "status", "issuetype", "priority",
                "assignee", "reporter", "created", "updated", "labels", "components"
            }
            custom_fields = {
                k: v for k, v in fields.items() 
                if k not in standard_fields and not k.startswith("customfield_")
            }
            
            return JiraIssue(
                id=issue_data.get("id", ""),
                key=issue_data.get("key", ""),
                title=fields.get("summary", ""),
                description=description,
                status=fields.get("status", {}).get("name", ""),
                issue_type=fields.get("issuetype", {}).get("name", ""),
                priority=fields.get("priority", {}).get("name", ""),
                assignee=assignee,
                reporter=reporter,
                created=created,
                updated=updated,
                labels=labels,
                components=components,
                custom_fields=custom_fields
            )
        except Exception as e:
            logger.error(f"Error parsing Jira issue: {e}")
            return None
    
    def _extract_description_text(self, description_data: Any) -> str:
        """Extract plain text from Atlassian Document Format"""
        if not description_data:
            return ""
        
        if isinstance(description_data, str):
            return description_data
        
        if isinstance(description_data, dict):
            content = description_data.get("content", [])
            text_parts = []
            
            for item in content:
                if isinstance(item, dict):
                    if item.get("type") == "paragraph":
                        paragraph_content = item.get("content", [])
                        for text_item in paragraph_content:
                            if text_item.get("type") == "text":
                                text_parts.append(text_item.get("text", ""))
                    elif item.get("type") == "text":
                        text_parts.append(item.get("text", ""))
            
            return " ".join(text_parts)
        
        return str(description_data)
