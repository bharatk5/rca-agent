## Configuration Guide

### Environment Variables

#### Core Application Settings
```bash
# Application
DEBUG=false
SECRET_KEY=your-super-secret-key
APP_NAME=RCA Agent
APP_VERSION=1.0.0

# API
API_HOST=0.0.0.0
API_PORT=8000
API_PREFIX=/api/v1

# Authentication
ACCESS_TOKEN_EXPIRE_MINUTES=30
```

#### Jira Integration
```bash
# Required
JIRA_BASE_URL=https://your-domain.atlassian.net
JIRA_USERNAME=your-email@domain.com
JIRA_API_TOKEN=your-api-token

# Optional
JIRA_PROJECT_KEY=PROJ  # Limit to specific project
```

**Obtaining Jira API Token:**
1. Go to https://id.atlassian.com/manage-profile/security/api-tokens
2. Click "Create API token"
3. Give it a name and copy the token

#### Database Configuration

**ChromaDB:**
```bash
DATABASE_TYPE=chromadb
CHROMADB_HOST=localhost
CHROMADB_PORT=8001
CHROMADB_PERSIST_DIRECTORY=./chroma_db
```

**BigQuery:**
```bash
DATABASE_TYPE=bigquery
BIGQUERY_PROJECT_ID=your-gcp-project
BIGQUERY_DATASET_ID=rca_agent
GOOGLE_APPLICATION_CREDENTIALS=/path/to/service-account.json
```

#### LLM Provider Configuration

**OpenAI:**
```bash
LLM_PROVIDER=openai
LLM_MODEL=gpt-3.5-turbo
LLM_API_KEY=sk-your-openai-key
LLM_TEMPERATURE=0.7
LLM_MAX_TOKENS=1000
```

**Anthropic:**
```bash
LLM_PROVIDER=anthropic
LLM_MODEL=claude-3-sonnet-20240229
LLM_API_KEY=your-anthropic-key
```

**Ollama (Local):**
```bash
LLM_PROVIDER=ollama
LLM_MODEL=llama2
LLM_BASE_URL=http://localhost:11434
```

#### Agent Settings
```bash
AGENT_POLL_INTERVAL=300  # Check for new bugs every 5 minutes
AGENT_COLLECTION_NAME=jira_stories
```

#### Logging
```bash
LOG_LEVEL=INFO
LOG_FILE=./logs/rca-agent.log
```

### Security Configuration

#### Change Default Passwords
Edit `app/core/security.py` and update `USERS_DB`:

```python
USERS_DB = {
    "admin": {
        "username": "admin",
        "hashed_password": pwd_context.hash("your-new-admin-password"),
        "permissions": ["read", "write", "admin"]
    },
    "user": {
        "username": "user",
        "hashed_password": pwd_context.hash("your-new-user-password"),
        "permissions": ["read"]
    }
}
```

#### Generate Secret Key
```bash
python -c "import secrets; print(secrets.token_urlsafe(32))"
```

#### SSL/TLS Setup
For production, use a reverse proxy like Nginx:

```nginx
server {
    listen 443 ssl;
    server_name your-domain.com;
    
    ssl_certificate /path/to/certificate.crt;
    ssl_certificate_key /path/to/private.key;
    
    location / {
        proxy_pass http://localhost:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```
