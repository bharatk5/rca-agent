import os
from typing import Optional
from pydantic import BaseSettings, Field
from enum import Enum

class DatabaseType(str, Enum):
    CHROMADB = "chromadb"
    BIGQUERY = "bigquery"

class LLMProviderType(str, Enum):
    OPENAI = "openai"
    ANTHROPIC = "anthropic"
    OLLAMA = "ollama"

class Settings(BaseSettings):
    # App settings
    app_name: str = "RCA Agent"
    app_version: str = "1.0.0"
    debug: bool = False
    
    # API settings
    api_host: str = "0.0.0.0"
    api_port: int = 8000
    api_prefix: str = "/api/v1"
    
    # Authentication
    secret_key: str = Field(..., description="Secret key for JWT")
    algorithm: str = "HS256"
    access_token_expire_minutes: int = 30
    
    # Jira settings
    jira_base_url: str = Field(..., description="Jira base URL")
    jira_username: str = Field(..., description="Jira username")
    jira_api_token: str = Field(..., description="Jira API token")
    jira_project_key: Optional[str] = None
    
    # Database settings
    database_type: DatabaseType = DatabaseType.CHROMADB
    
    # ChromaDB settings
    chromadb_host: str = "localhost"
    chromadb_port: int = 8000
    chromadb_persist_directory: str = "./chroma_db"
    
    # BigQuery settings
    bigquery_project_id: Optional[str] = None
    bigquery_dataset_id: str = "rca_agent"
    google_application_credentials: Optional[str] = None
    
    # LLM settings
    llm_provider: LLMProviderType = LLMProviderType.OPENAI
    llm_model: str = "gpt-3.5-turbo"
    llm_api_key: Optional[str] = None
    llm_base_url: Optional[str] = None
    llm_temperature: float = 0.7
    llm_max_tokens: int = 1000
    
    # Agent settings
    agent_poll_interval: int = 300  # 5 minutes
    agent_collection_name: str = "jira_stories"
    
    # Logging
    log_level: str = "INFO"
    log_file: Optional[str] = None
    
    class Config:
        env_file = ".env"
        case_sensitive = False

settings = Settings()
