import logging
from typing import List, Dict
from utils.jira_utils import JiraClient
from utils.chroma_db_utils import ChromaDBUtility
from utils.jira_utils import JiraConfig

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)


class RCAAgent:
    def __init__(self, db: ChromaDBUtility, jira: JiraClient):
        self.db = db
        self.jira = jira

    def process_new_bugs(self, jql: str = 'type=Bug AND status="Open"', top_k: int = 5) -> Dict[str, List[Dict]]:
        """
        - Fetches open bug issues from Jira.
        - Performs semantic search against indexed stories.
        - Returns similar story matches for each bug.
        """
        logger.info("Starting RCA process on new bugs.")
        results: Dict[str, List[Dict]] = {}
        bugs = self.jira.get_issues(jql=jql)

        for bug in bugs:
            details = self.jira.extract_issue_details(bug)
            if not details:
                continue

            query_text = f"{details['title']}\n{details['description']}"
            matches = self.db.semantic_search(query=query_text, top_k=top_k)
            results[details["issue_id"]] = matches
            logger.info(f"Matched bug '{details['issue_id']}' to {len(matches)} related issues.")

        return results
