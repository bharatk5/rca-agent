from fastapi import APIRouter, Depends
from datetime import datetime
from ...models.api_models import HealthResponse
from ...core.security import require_read

router = APIRouter()

@router.get("/health", response_model=HealthResponse)
async def health_check():
    """Health check endpoint"""
    return HealthResponse(
        status="healthy",
        timestamp=datetime.now(),
        services={
            "api": "healthy",
            "database": "healthy",
            "jira": "healthy",
            "llm": "healthy"
        }
    )

@router.get("/health/protected", response_model=HealthResponse)
async def protected_health_check(current_user = Depends(require_read)):
    """Protected health check endpoint"""
    return HealthResponse(
        status="healthy",
        timestamp=datetime.now(),
        services={
            "api": "healthy",
            "database": "healthy",
            "jira": "healthy",
            "llm": "healthy",
            "auth": "healthy"
        }
    )

