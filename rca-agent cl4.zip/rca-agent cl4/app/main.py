from fastapi import FastAPI, Depends, HTTPException, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.security import HTTPBearer
from contextlib import asynccontextmanager
import logging
import asyncio
from typing import Dict, Any

from .config import settings
from .core.security import verify_token
from .api.v1 import jira, agent, health
from .services.jira_service import JiraService
from .services.llm_service import LLMService, LLMConfig, LLMProvider
from .services.rca_agent import RCAAgent
from .database.chromadb_client import ChromaDBClient
from .database.bigquery_client import BigQueryClient
from .utils.logging import setup_logging

# Global variables for services
jira_service = None
llm_service = None
rca_agent = None
database = None

@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan management"""
    # Startup
    await startup_event()
    yield
    # Shutdown
    await shutdown_event()

# Setup logging
setup_logging()
logger = logging.getLogger(__name__)

# Create FastAPI app
app = FastAPI(
    title=settings.app_name,
    version=settings.app_version,
    description="Root Cause Analysis Agent for Jira Issues",
    lifespan=lifespan
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Configure appropriately for production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Include routers
app.include_router(health.router, prefix=settings.api_prefix, tags=["health"])
app.include_router(jira.router, prefix=settings.api_prefix, tags=["jira"])
app.include_router(agent.router, prefix=settings.api_prefix, tags=["agent"])

async def startup_event():
    """Initialize services on startup"""
    global jira_service, llm_service, rca_agent, database
    
    try:
        logger.info("Starting up RCA Agent application...")
        
        # Initialize database
        if settings.database_type == "chromadb":
            database = ChromaDBClient(
                host=settings.chromadb_host,
                port=settings.chromadb_port,
                persist_directory=settings.chromadb_persist_directory
            )
        elif settings.database_type == "bigquery":
            database = BigQueryClient(
                project_id=settings.bigquery_project_id,
                dataset_id=settings.bigquery_dataset_id
            )
        else:
            raise ValueError(f"Unsupported database type: {settings.database_type}")
        
        # Initialize Jira service
        jira_service = JiraService(
            base_url=settings.jira_base_url,
            username=settings.jira_username,
            api_token=settings.jira_api_token
        )
        
        # Initialize LLM service
        llm_config = LLMConfig(
            provider=LLMProvider(settings.llm_provider),
            model=settings.llm_model,
            api_key=settings.llm_api_key,
            base_url=settings.llm_base_url,
            temperature=settings.llm_temperature,
            max_tokens=settings.llm_max_tokens
        )
        llm_service = LLMService(llm_config)
        
        # Initialize RCA agent
        rca_agent = RCAAgent(
            jira_service=jira_service,
            llm_service=llm_service,
            database=database,
            collection_name=settings.agent_collection_name,
            poll_interval=settings.agent_poll_interval
        )
        
        # Initialize agent
        await rca_agent.initialize()
        
        # Start monitoring in background
        asyncio.create_task(rca_agent.start_monitoring())
        
        logger.info("RCA Agent application started successfully")
        
    except Exception as e:
        logger.error(f"Failed to start application: {e}")
        raise

async def shutdown_event():
    """Cleanup on shutdown"""
    global rca_agent
    
    try:
        logger.info("Shutting down RCA Agent application...")
        
        if rca_agent:
            await rca_agent.cleanup()
        
        logger.info("RCA Agent application shutdown complete")
        
    except Exception as e:
        logger.error(f"Error during shutdown: {e}")

# Dependency to get services
def get_jira_service() -> JiraService:
    if not jira_service:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Jira service not initialized"
        )
    return jira_service

def get_llm_service() -> LLMService:
    if not llm_service:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="LLM service not initialized"
        )
    return llm_service

def get_rca_agent() -> RCAAgent:
    if not rca_agent:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="RCA agent not initialized"
        )
    return rca_agent

def get_database():
    if not database:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Database not initialized"
        )
    return database

# Store dependencies in app state for access from routers
app.state.get_jira_service = get_jira_service
app.state.get_llm_service = get_llm_service
app.state.get_rca_agent = get_rca_agent
app.state.get_database = get_database
