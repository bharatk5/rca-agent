from abc import ABC, abstractmethod
from typing import List, Dict, Any, Optional
from dataclasses import dataclass

@dataclass
class JiraDocument:
    issue_id: str
    issue_title: str
    issue_description: str
    issue_categories: List[str]
    metadata: Dict[str, Any]
    embedding: Optional[List[float]] = None

class DatabaseInterface(ABC):
    """Abstract base class for database operations"""
    
    @abstractmethod
    async def connect(self) -> None:
        """Establish database connection"""
        pass
    
    @abstractmethod
    async def disconnect(self) -> None:
        """Close database connection"""
        pass
    
    @abstractmethod
    async def create_collection(self, collection_name: str) -> bool:
        """Create a new collection"""
        pass
    
    @abstractmethod
    async def add_documents(self, collection_name: str, documents: List[JiraDocument]) -> bool:
        """Add documents to collection"""
        pass
    
    @abstractmethod
    async def semantic_search(self, collection_name: str, query: str, limit: int = 10) -> List[Dict[str, Any]]:
        """Perform semantic search"""
        pass
    
    @abstractmethod
    async def get_document(self, collection_name: str, document_id: str) -> Optional[JiraDocument]:
        """Retrieve a specific document"""
        pass
    
    @abstractmethod
    async def update_document(self, collection_name: str, document_id: str, document: JiraDocument) -> bool:
        """Update an existing document"""
        pass
    
    @abstractmethod
    async def delete_document(self, collection_name: str, document_id: str) -> bool:
        """Delete a document"""
        pass