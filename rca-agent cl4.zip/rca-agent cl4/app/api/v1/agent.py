# app/api/v1/agent.py
from fastapi import APIRouter, Depends, HTTPException, status, Request
from typing import List, Dict, Any

from ...models.api_models import (
    RCARequest, RCAResponse, AgentStatusResponse, 
    SearchRequest, JiraIssueResponse
)
from ...core.security import require_read, require_write, require_admin
from ...services.rca_agent import RCAAgent

router = APIRouter()

@router.get("/agent/status", response_model=AgentStatusResponse)
async def get_agent_status(
    request: Request,
    current_user = Depends(require_read)
):
    """Get RCA agent status"""
    rca_agent: RCAAgent = request.app.state.get_rca_agent()
    
    return AgentStatusResponse(
        running=rca_agent.running,
        last_check=rca_agent.last_check,
        collection_name=rca_agent.collection_name,
        poll_interval=rca_agent.poll_interval
    )

@router.post("/agent/analyze", response_model=RCAResponse)
async def analyze_bug(
    rca_request: RCARequest,
    request: Request,
    current_user = Depends(require_read)
):
    """Perform RCA analysis on a specific bug"""
    rca_agent: RCAAgent = request.app.state.get_rca_agent()
    jira_service = request.app.state.get_jira_service()
    
    # Get the bug issue from Jira
    async with jira_service:
        bug_issue = await jira_service.get_issue(rca_request.issue_key)
        
        if not bug_issue:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Issue {rca_request.issue_key} not found"
            )
        
        # Perform RCA analysis
        rca_result = await rca_agent.analyze_bug(bug_issue)
        
        if not rca_result:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Failed to perform RCA analysis"
            )
        
        return RCAResponse(
            bug_issue=JiraIssueResponse(
                id=rca_result.bug_issue.id,
                key=rca_result.bug_issue.key,
                title=rca_result.bug_issue.title,
                description=rca_result.bug_issue.description,
                status=rca_result.bug_issue.status,
                issue_type=rca_result.bug_issue.issue_type,
                priority=rca_result.bug_issue.priority,
                assignee=rca_result.bug_issue.assignee,
                reporter=rca_result.bug_issue.reporter,
                created=rca_result.bug_issue.created,
                updated=rca_result.bug_issue.updated,
                labels=rca_result.bug_issue.labels,
                components=rca_result.bug_issue.components
            ),
            similar_issues=rca_result.similar_issues,
            analysis=rca_result.analysis,
            confidence_score=rca_result.confidence_score,
            recommended_actions=rca_result.recommended_actions,
            created_at=rca_result.created_at
        )

@router.post("/agent/search", response_model=List[Dict[str, Any]])
async def semantic_search(
    search_request: SearchRequest,
    request: Request,
    current_user = Depends(require_read)
):
    """Perform semantic search in the story collection"""
    database = request.app.state.get_database()
    rca_agent: RCAAgent = request.app.state.get_rca_agent()
    
    results = await database.semantic_search(
        collection_name=rca_agent.collection_name,
        query=search_request.query,
        limit=search_request.limit
    )
    
    return results

@router.post("/agent/collection/update", response_model=Dict[str, str])
async def update_story_collection(
    request: Request,
    current_user = Depends(require_admin)
):
    """Update the story collection with latest stories from Jira"""
    rca_agent: RCAAgent = request.app.state.get_rca_agent()
    
    try:
        await rca_agent.update_story_collection()
        return {"message": "Story collection updated successfully"}
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to update story collection: {str(e)}"
        )

@router.post("/agent/start", response_model=Dict[str, str])
async def start_agent_monitoring(
    request: Request,
    current_user = Depends(require_admin)
):
    """Start RCA agent monitoring"""
    rca_agent: RCAAgent = request.app.state.get_rca_agent()
    
    if rca_agent.running:
        return {"message": "Agent is already running"}
    
    # Start monitoring in background
    import asyncio
    asyncio.create_task(rca_agent.start_monitoring())
    
    return {"message": "Agent monitoring started"}

@router.post("/agent/stop", response_model=Dict[str, str])
async def stop_agent_monitoring(
    request: Request,
    current_user = Depends(require_admin)
):
    """Stop RCA agent monitoring"""
    rca_agent: RCAAgent = request.app.state.get_rca_agent()
    
    if not rca_agent.running:
        return {"message": "Agent is not running"}
    
    rca_agent.stop_monitoring()
    return {"message": "Agent monitoring stopped"}
