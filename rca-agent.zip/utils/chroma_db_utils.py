from typing import List, Dict, Any
import logging
import chromadb
from chromadb.utils import embedding_functions

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)

class ChromaDBUtility:
    def __init__(self, collection_name: str):
        try:
            self.client = chromadb.Client()
            self.embedding_func = embedding_functions.DefaultEmbeddingFunction()
            self.collection = self.client.get_or_create_collection(
                name=collection_name,
                embedding_function=self.embedding_func
            )
            logger.info(f"ChromaDB collection '{collection_name}' initialized.")
        except Exception as e:
            logger.error("Failed to initialize ChromaDB", exc_info=True)
            raise e

    def add_issue(self, issue_id: str, title: str, description: str,
                  categories: List[str], metadata: Dict[str, Any] = {}) -> None:
        try:
            document = f"{title}\n{description}"
            enriched_metadata = {
                "issue_id": issue_id,
                "title": title,
                "description": description,
                "categories": categories,
                **metadata
            }
            self.collection.add(
                documents=[document],
                metadatas=[enriched_metadata],
                ids=[issue_id]
            )
            logger.info(f"Issue '{issue_id}' added to ChromaDB.")
        except Exception as e:
            logger.error(f"Error adding issue '{issue_id}'", exc_info=True)

    def semantic_search(self, query: str, top_k: int = 5) -> List[Dict[str, Any]]:
        try:
            results = self.collection.query(
                query_texts=[query],
                n_results=top_k
            )
            matches = []
            for i in range(len(results.get("documents", [[]])[0])):
                matches.append({
                    "id": results["ids"][0][i],
                    "document": results["documents"][0][i],
                    "metadata": results["metadatas"][0][i]
                })
            logger.info(f"Semantic search completed: {len(matches)} matches found.")
            return matches
        except Exception as e:
            logger.error("Semantic search failed", exc_info=True)
            return []

    def delete_issue(self, issue_id: str) -> None:
        try:
            self.collection.delete(ids=[issue_id])
            logger.info(f"Issue '{issue_id}' deleted from ChromaDB.")
        except Exception as e:
            logger.error(f"Failed to delete issue '{issue_id}'", exc_info=True)
