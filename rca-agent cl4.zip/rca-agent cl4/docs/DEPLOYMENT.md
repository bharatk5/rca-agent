# RCA Agent Deployment Guide

This guide provides comprehensive instructions for deploying and configuring the RCA Agent application.

## Prerequisites

### System Requirements
- Python 3.11 or higher
- Docker and Docker Compose (for containerized deployment)
- 4GB+ RAM (recommended)
- 10GB+ disk space

### External Dependencies
- **Jira Server/Cloud**: With API access and valid credentials
- **LLM Provider**: OpenAI, Anthropic, or Ollama setup
- **Database**: ChromaDB (default) or Google BigQuery

## Quick Start with Docker

### 1. Clone and Setup
```bash
git clone <your-repo-url>
cd rca-agent
cp .env.example .env
```

### 2. Configure Environment
Edit `.env` file with your settings:

```bash
# Jira Configuration
JIRA_BASE_URL=https://your-company.atlassian.net
JIRA_USERNAME=your-email@company.com
JIRA_API_TOKEN=your-jira-api-token

# LLM Configuration
LLM_PROVIDER=openai
LLM_MODEL=gpt-3.5-turbo
LLM_API_KEY=your-openai-api-key

# Security
SECRET_KEY=generate-a-secure-secret-key
```

### 3. Deploy with Docker Compose
```bash
docker-compose up -d
```

### 4. Initialize Database
```bash
docker-compose exec rca-agent python scripts/setup_db.py
```

### 5. Access the Application
- API: http://localhost:8000
- Documentation: http://localhost:8000/docs
- Health Check: http://localhost:8000/api/v1/health

## Manual Installation

### 1. Python Environment Setup
```bash
# Create virtual environment
python3.11 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

### 2. Environment Configuration
```bash
cp .env.example .env
# Edit .env with your configuration
```

### 3. Database Setup

#### ChromaDB (Default)
```bash
# Start ChromaDB server
docker run -d --name chromadb -p 8001:8000 ghcr.io/chroma-core/chroma:latest

# Or install locally
pip install chromadb
```

#### BigQuery (Alternative)
```bash
# Set up Google Cloud credentials
export GOOGLE_APPLICATION_CREDENTIALS=/path/to/service-account.json

# Update .env
DATABASE_TYPE=bigquery
BIGQUERY_PROJECT_ID=your-gcp-project
```

### 4. Initialize Database
```bash
python scripts/setup_db.py
```

### 5. Run Application
```bash
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

## Configuration Guide

### Environment Variables

#### Core Application Settings
```bash
# Application
DEBUG=false
SECRET_KEY=your-super-secret-key
APP_NAME=RCA Agent
APP_VERSION=1.0.0

# API
API_HOST=0.0.0.0
API_PORT=8000
API_PREFIX=/api/v1

# Authentication
ACCESS_TOKEN_EXPIRE_MINUTES=30
```

#### Jira Integration
```bash
# Required
JIRA_BASE_URL=https://your-domain.atlassian.net
JIRA_USERNAME=your-email@domain.com
JIRA_API_TOKEN=your-api-token

# Optional
JIRA_PROJECT_KEY=PROJ  # Limit to specific project
```

**Obtaining Jira API Token:**
1. Go to https://id.atlassian.com/manage-profile/security/api-tokens
2. Click "Create API token"
3. Give it a name and copy the token

#### Database Configuration

**ChromaDB:**
```bash
DATABASE_TYPE=chromadb
CHROMADB_HOST=localhost
CHROMADB_PORT=8001
CHROMADB_PERSIST_DIRECTORY=./chroma_db
```

**BigQuery:**
```bash
DATABASE_TYPE=bigquery
BIGQUERY_PROJECT_ID=your-gcp-project
BIGQUERY_DATASET_ID=rca_agent
GOOGLE_APPLICATION_CREDENTIALS=/path/to/service-account.json
```

#### LLM Provider Configuration

**OpenAI:**
```bash
LLM_PROVIDER=openai
LLM_MODEL=gpt-3.5-turbo
LLM_API_KEY=sk-your-openai-key
LLM_TEMPERATURE=0.7
LLM_MAX_TOKENS=1000
```

**Anthropic:**
```bash
LLM_PROVIDER=anthropic
LLM_MODEL=claude-3-sonnet-20240229
LLM_API_KEY=your-anthropic-key
```

**Ollama (Local):**
```bash
LLM_PROVIDER=ollama
LLM_MODEL=llama2
LLM_BASE_URL=http://localhost:11434
```

#### Agent Settings
```bash
AGENT_POLL_INTERVAL=300  # Check for new bugs every 5 minutes
AGENT_COLLECTION_NAME=jira_stories
```

#### Logging
```bash
LOG_LEVEL=INFO
LOG_FILE=./logs/rca-agent.log
```

### Security Configuration

#### Change Default Passwords
Edit `app/core/security.py` and update `USERS_DB`:

```python
USERS_DB = {
    "admin": {
        "username": "admin",
        "hashed_password": pwd_context.hash("your-new-admin-password"),
        "permissions": ["read", "write", "admin"]
    },
    "user": {
        "username": "user",
        "hashed_password": pwd_context.hash("your-new-user-password"),
        "permissions": ["read"]
    }
}
```

#### Generate Secret Key
```bash
python -c "import secrets; print(secrets.token_urlsafe(32))"
```

#### SSL/TLS Setup
For production, use a reverse proxy like Nginx:

```nginx
server {
    listen 443 ssl;
    server_name your-domain.com;
    
    ssl_certificate /path/to/certificate.crt;
    ssl_certificate_key /path/to/private.key;
    
    location / {
        proxy_pass http://localhost:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

## Production Deployment

### Docker Production Setup

**docker-compose.prod.yml:**
```yaml
version: '3.8'

services:
  rca-agent:
    build: 
      context: .
      dockerfile: Dockerfile.prod
    ports:
      - "8000:8000"
    environment:
      - DEBUG=false
      - LOG_LEVEL=WARNING
    env_file:
      - .env.prod
    volumes:
      - ./data:/app/data
      - ./logs:/app/logs
    restart: unless-stopped
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8000/api/v1/health"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 40s

  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf
      - ./ssl:/etc/nginx/ssl
    depends_on:
      - rca-agent
    restart: unless-stopped
```

### Kubernetes Deployment

**k8s/namespace.yaml:**
```yaml
apiVersion: v1
kind: Namespace
metadata:
  name: rca-agent
```

**k8s/configmap.yaml:**
```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: rca-agent-config
  namespace: rca-agent
data:
  DEBUG: "false"
  LOG_LEVEL: "INFO"
  API_HOST: "0.0.0.0"
  API_PORT: "8000"
  DATABASE_TYPE: "chromadb"
  AGENT_POLL_INTERVAL: "300"
```

**k8s/secret.yaml:**
```yaml
apiVersion: v1
kind: Secret
metadata:
  name: rca-agent-secrets
  namespace: rca-agent
type: Opaque
stringData:
  SECRET_KEY: "your-secret-key"
  JIRA_API_TOKEN: "your-jira-token"
  LLM_API_KEY: "your-llm-api-key"
```

**k8s/deployment.yaml:**
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: rca-agent
  namespace: rca-agent
spec:
  replicas: 2
  selector:
    matchLabels:
      app: rca-agent
  template:
    metadata:
      labels:
        app: rca-agent
    spec:
      containers:
      - name: rca-agent
        image: rca-agent:latest
        ports:
        - containerPort: 8000
        envFrom:
        - configMapRef:
            name: rca-agent-config
        - secretRef:
            name: rca-agent-secrets
        volumeMounts:
        - name: data-volume
          mountPath: /app/data
        livenessProbe:
          httpGet:
            path: /api/v1/health
            port: 8000
          initialDelaySeconds: 30
          periodSeconds: 30
        readinessProbe:
          httpGet:
            path: /api/v1/health
            port: 8000
          initialDelaySeconds: 5
          periodSeconds: 10
      volumes:
      - name: data-volume
        persistentVolumeClaim:
          claimName: rca-agent-pvc
```

### Monitoring and Logging

#### Prometheus Metrics (Optional)
Add to requirements.txt:
```
prometheus-client==0.19.0
```

#### Structured Logging
The application uses structured logging. For production, consider:
- Centralized logging (ELK Stack, Fluentd)
- Log aggregation services (Datadog, New Relic)
- Log rotation and retention policies

#### Health Checks
- Application health: `/api/v1/health`
- Protected health: `/api/v1/health/protected`
- Agent status: `/api/v1/agent/status`

## Troubleshooting

### Common Issues

#### 1. ChromaDB Connection Failed
```bash
# Check if ChromaDB is running
docker ps | grep chroma

# Check logs
docker logs chromadb

# Restart ChromaDB
docker restart chromadb
```

#### 2. Jira Authentication Failed
```bash
# Test Jira connection
curl -u "email@domain.com:api-token" \
  "https://your-domain.atlassian.net/rest/api/3/myself"

# Check API token permissions
# Verify base URL format
```

#### 3. LLM Provider Issues
```bash
# Test OpenAI connection
curl -H "Authorization: Bearer $OPENAI_API_KEY" \
  "https://api.openai.com/v1/models"

# Check API key and billing
# Verify model availability
```

#### 4. Database Migration Issues
```bash
# Create backup before migration
python scripts/migrate_data.py

# Check database connections
# Verify credentials and permissions
```

#### 5. Memory Issues
```bash
# Increase Docker memory limits
# Monitor memory usage
docker stats rca-agent

# Reduce batch sizes in configuration
# Implement pagination for large datasets
```

### Debugging

#### Enable Debug Mode
```bash
DEBUG=true
LOG_LEVEL=DEBUG
```

#### Check Application Logs
```bash
# Docker
docker logs rca-agent

# Manual installation
tail -f logs/rca-agent.log
```

#### Database Debugging
```bash
# ChromaDB
# Check collection status
# Verify embeddings

# BigQuery
# Check table schema
# Verify permissions
```

# RCA Agent Deployment Guide

This guide provides comprehensive instructions for deploying and configuring the RCA Agent application.

## Prerequisites

### System Requirements
- Python 3.11 or higher
- Docker and Docker Compose (for containerized deployment)
- 4GB+ RAM (recommended)
- 10GB+ disk space

### External Dependencies
- **Jira Server/Cloud**: With API access and valid credentials
- **LLM Provider**: OpenAI, Anthropic, or Ollama setup
- **Database**: ChromaDB (default) or Google BigQuery

## Quick Start with Docker

### 1. Clone and Setup
```bash
git clone <your-repo-url>
cd rca-agent
cp .env.example .env
```

### 2. Configure Environment
Edit `.env` file with your settings:

```bash
# Jira Configuration
JIRA_BASE_URL=https://your-company.atlassian.net
JIRA_USERNAME=your-email@company.com
JIRA_API_TOKEN=your-jira-api-token

# LLM Configuration
LLM_PROVIDER=openai
LLM_MODEL=gpt-3.5-turbo
LLM_API_KEY=your-openai-api-key

# Security
SECRET_KEY=generate-a-secure-secret-key
```

### 3. Deploy with Docker Compose
```bash
docker-compose up -d
```

### 4. Initialize Database
```bash
docker-compose exec rca-agent python scripts/setup_db.py
```

### 5. Access the Application
- API: http://localhost:8000
- Documentation: http://localhost:8000/docs
- Health Check: http://localhost:8000/api/v1/health

## Manual Installation

### 1. Python Environment Setup
```bash
# Create virtual environment
python3.11 -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install dependencies
pip install -r requirements.txt
```

### 2. Environment Configuration
```bash
cp .env.example .env
# Edit .env with your configuration
```

### 3. Database Setup

#### ChromaDB (Default)
```bash
# Start ChromaDB server
docker run -d --name chromadb -p 8001:8000 ghcr.io/chroma-core/chroma:latest

# Or install locally
pip install chromadb
```

#### BigQuery (Alternative)
```bash
# Set up Google Cloud credentials
export GOOGLE_APPLICATION_CREDENTIALS=/path/to/service-account.json

# Update .env
DATABASE_TYPE=bigquery
BIGQUERY_PROJECT_ID=your-gcp-project
```

### 4. Initialize Database
```bash
python scripts/setup_db.py
```

### 5. Run Application
```bash
uvicorn app.main:app --host 0.0.0.0 --port 8000 --reload
```

## Configuration Guide

### Environment Variables

#### Core Application Settings
```bash
# Application
DEBUG=false
SECRET_KEY=your-super-secret-key
APP_NAME=RCA Agent
APP_VERSION=1.0.0

# API
API_HOST=0.0.0.0
API_PORT=8000
API_PREFIX=/api/v1

# Authentication
ACCESS_TOKEN_EXPIRE_MINUTES=30
```

#### Jira Integration
```bash
# Required
JIRA_BASE_URL=https://your-domain.atlassian.net
JIRA_USERNAME=your-email@domain.com
JIRA_API_TOKEN=your-api-token

# Optional
JIRA_PROJECT_KEY=PROJ  # Limit to specific project
```

**Obtaining Jira API Token:**
1. Go to https://id.atlassian.com/manage-profile/security/api-tokens
2. Click "Create API token"
3. Give it a name and copy the token

#### Database Configuration

**ChromaDB:**
```bash
DATABASE_TYPE=chromadb
CHROMADB_HOST=localhost
CHROMADB_PORT=8001
CHROMADB_PERSIST_DIRECTORY=./chroma_db
```

**BigQuery:**
```bash
DATABASE_TYPE=bigquery
BIGQUERY_PROJECT_ID=your-gcp-project
BIGQUERY_DATASET_ID=rca_agent
GOOGLE_APPLICATION_CREDENTIALS=/path/to/service-account.json
```

#### LLM Provider Configuration

**OpenAI:**
```bash
LLM_PROVIDER=openai
LLM_MODEL=gpt-3.5-turbo
LLM_API_KEY=sk-your-openai-key
LLM_TEMPERATURE=0.7
LLM_MAX_TOKENS=1000
```

**Anthropic:**
```bash
LLM_PROVIDER=anthropic
LLM_MODEL=claude-3-sonnet-20240229
LLM_API_KEY=your-anthropic-key
```

**Ollama (Local):**
```bash
LLM_PROVIDER=ollama
LLM_MODEL=llama2
LLM_BASE_URL=http://localhost:11434
```

#### Agent Settings
```bash
AGENT_POLL_INTERVAL=300  # Check for new bugs every 5 minutes
AGENT_COLLECTION_NAME=jira_stories
```

#### Logging
```bash
LOG_LEVEL=INFO
LOG_FILE=./logs/rca-agent.log
```

### Security Configuration

#### Change Default Passwords
Edit `app/core/security.py` and update `USERS_DB`:

```python
USERS_DB = {
    "admin": {
        "username": "admin",
        "hashed_password": pwd_context.hash("your-new-admin-password"),
        "permissions": ["read", "write", "admin"]
    },
    "user": {
        "username": "user",
        "hashed_password": pwd_context.hash("your-new-user-password"),
        "permissions": ["read"]
    }
}
```

#### Generate Secret Key
```bash
python -c "import secrets; print(secrets.token_urlsafe(32))"
```

#### SSL/TLS Setup
For production, use a reverse proxy like Nginx:

```nginx
server {
    listen 443 ssl;
    server_name your-domain.com;
    
    ssl_certificate /path/to/certificate.crt;
    ssl_certificate_key /path/to/private.key;
    
    location / {
        proxy_pass http://localhost:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

## Production Deployment

### Docker Production Setup

**docker-compose.prod.yml:**
```yaml
version: '3.8'

services:
  rca-agent:
    build: 
      context: .
      dockerfile: Dockerfile.prod
    ports:
      - "8000:8000"
    environment:
      - DEBUG=false
      - LOG_LEVEL=WARNING
    env_file:
      - .env.prod
    volumes:
      - ./data:/app/data
      - ./logs:/app/logs
    restart: unless-stopped
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8000/api/v1/health"]
      interval: 30s
      timeout: 10s
      retries: 3
      start_period: 40s

  nginx:
    image: nginx:alpine
    ports:
      - "80:80"
      - "443:443"
    volumes:
      - ./nginx.conf:/etc/nginx/nginx.conf
      - ./ssl:/etc/nginx/ssl
    depends_on:
      - rca-agent
    restart: unless-stopped
```

### Kubernetes Deployment

**k8s/namespace.yaml:**
```yaml
apiVersion: v1
kind: Namespace
metadata:
  name: rca-agent
```

**k8s/configmap.yaml:**
```yaml
apiVersion: v1
kind: ConfigMap
metadata:
  name: rca-agent-config
  namespace: rca-agent
data:
  DEBUG: "false"
  LOG_LEVEL: "INFO"
  API_HOST: "0.0.0.0"
  API_PORT: "8000"
  DATABASE_TYPE: "chromadb"
  AGENT_POLL_INTERVAL: "300"
```

**k8s/secret.yaml:**
```yaml
apiVersion: v1
kind: Secret
metadata:
  name: rca-agent-secrets
  namespace: rca-agent
type: Opaque
stringData:
  SECRET_KEY: "your-secret-key"
  JIRA_API_TOKEN: "your-jira-token"
  LLM_API_KEY: "your-llm-api-key"
```

**k8s/deployment.yaml:**
```yaml
apiVersion: apps/v1
kind: Deployment
metadata:
  name: rca-agent
  namespace: rca-agent
spec:
  replicas: 2
  selector:
    matchLabels:
      app: rca-agent
  template:
    metadata:
      labels:
        app: rca-agent
    spec:
      containers:
      - name: rca-agent
        image: rca-agent:latest
        ports:
        - containerPort: 8000
        envFrom:
        - configMapRef:
            name: rca-agent-config
        - secretRef:
            name: rca-agent-secrets
        volumeMounts:
        - name: data-volume
          mountPath: /app/data
        livenessProbe:
          httpGet:
            path: /api/v1/health
            port: 8000
          initialDelaySeconds: 30
          periodSeconds: 30
        readinessProbe:
          httpGet:
            path: /api/v1/health
            port: 8000
          initialDelaySeconds: 5
          periodSeconds: 10
      volumes:
      - name: data-volume
        persistentVolumeClaim:
          claimName: rca-agent-pvc
```

### Monitoring and Logging

#### Prometheus Metrics (Optional)
Add to requirements.txt:
```
prometheus-client==0.19.0
```

#### Structured Logging
The application uses structured logging. For production, consider:
- Centralized logging (ELK Stack, Fluentd)
- Log aggregation services (Datadog, New Relic)
- Log rotation and retention policies

#### Health Checks
- Application health: `/api/v1/health`
- Protected health: `/api/v1/health/protected`
- Agent status: `/api/v1/agent/status`

## Troubleshooting

### Common Issues

#### 1. ChromaDB Connection Failed
```bash
# Check if ChromaDB is running
docker ps | grep chroma

# Check logs
docker logs chromadb

# Restart ChromaDB
docker restart chromadb
```

#### 2. Jira Authentication Failed
```bash
# Test Jira connection
curl -u "email@domain.com:api-token" \
  "https://your-domain.atlassian.net/rest/api/3/myself"

# Check API token permissions
# Verify base URL format
```

#### 3. LLM Provider Issues
```bash
# Test OpenAI connection
curl -H "Authorization: Bearer $OPENAI_API_KEY" \
  "https://api.openai.com/v1/models"

# Check API key and billing
# Verify model availability
```

#### 4. Database Migration Issues
```bash
# Create backup before migration
python scripts/migrate_data.py

# Check database connections
# Verify credentials and permissions
```

#### 5. Memory Issues
```bash
# Increase Docker memory limits
# Monitor memory usage
docker stats rca-agent

# Reduce batch sizes in configuration
# Implement pagination for large datasets
```

### Debugging

#### Enable Debug Mode
```bash
DEBUG=true
LOG_LEVEL=DEBUG
```

#### Check Application Logs
```bash
# Docker
docker logs rca-agent

# Manual installation
tail -f logs/rca-agent.log
```

#### Database Debugging
```bash
# ChromaDB
# Check collection status
# Verify embeddings

# BigQuery
# Check table schema
# Verify permissions
```

## Maintenance

### Regular Tasks

#### 1. Update Story Collection
```bash
curl -X POST "http://