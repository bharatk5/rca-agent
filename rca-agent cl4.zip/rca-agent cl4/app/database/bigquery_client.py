from google.cloud import bigquery
from google.cloud.exceptions import NotFound
from typing import List, Dict, Any, Optional
import json
import logging
from .base import DatabaseInterface, JiraDocument

logger = logging.getLogger(__name__)

class BigQueryClient(DatabaseInterface):
    """BigQuery implementation for database operations"""
    
    def __init__(self, project_id: str, dataset_id: str = "rca_agent"):
        self.project_id = project_id
        self.dataset_id = dataset_id
        self.client = None
        self.dataset = None
    
    async def connect(self) -> None:
        """Establish BigQuery connection"""
        try:
            self.client = bigquery.Client(project=self.project_id)
            self.dataset = self.client.dataset(self.dataset_id)
            
            # Create dataset if it doesn't exist
            try:
                self.client.get_dataset(self.dataset)
            except NotFound:
                dataset = bigquery.Dataset(self.dataset)
                dataset.location = "US"
                self.client.create_dataset(dataset)
                logger.info(f"Created dataset {self.dataset_id}")
            
            logger.info(f"Connected to BigQuery project {self.project_id}")
        except Exception as e:
            logger.error(f"Failed to connect to BigQuery: {e}")
            raise
    
    async def disconnect(self) -> None:
        """Close BigQuery connection"""
        if self.client:
            self.client.close()
            self.client = None
            logger.info("Disconnected from BigQuery")
    
    async def create_collection(self, collection_name: str) -> bool:
        """Create a new table in BigQuery"""
        try:
            if not self.client:
                await self.connect()
            
            table_id = f"{self.project_id}.{self.dataset_id}.{collection_name}"
            
            schema = [
                bigquery.SchemaField("issue_id", "STRING", mode="REQUIRED"),
                bigquery.SchemaField("issue_title", "STRING", mode="REQUIRED"),
                bigquery.SchemaField("issue_description", "STRING", mode="REQUIRED"),
                bigquery.SchemaField("issue_categories", "STRING", mode="REPEATED"),
                bigquery.SchemaField("metadata", "JSON", mode="NULLABLE"),
                bigquery.SchemaField("embedding", "FLOAT", mode="REPEATED"),
                bigquery.SchemaField("created_at", "TIMESTAMP", mode="REQUIRED"),
                bigquery.SchemaField("updated_at", "TIMESTAMP", mode="REQUIRED"),
            ]
            
            table = bigquery.Table(table_id, schema=schema)
            
            try:
                self.client.create_table(table)
                logger.info(f"Created table {collection_name}")
            except Exception as e:
                if "already exists" not in str(e).lower():
                    raise e
                logger.info(f"Table {collection_name} already exists")
            
            return True
        except Exception as e:
            logger.error(f"Failed to create table {collection_name}: {e}")
            return False
    
    async def add_documents(self, collection_name: str, documents: List[JiraDocument]) -> bool:
        """Add documents to BigQuery table"""
        try:
            if not self.client:
                await self.connect()
            
            table_id = f"{self.project_id}.{self.dataset_id}.{collection_name}"
            
            rows_to_insert = []
            for doc in documents:
                row = {
                    "issue_id": doc.issue_id,
                    "issue_title": doc.issue_title,
                    "issue_description": doc.issue_description,
                    "issue_categories": doc.issue_categories,
                    "metadata": json.dumps(doc.metadata) if doc.metadata else None,
                    "embedding": doc.embedding or [],
                    "created_at": bigquery.enums.SqlTypeNames.TIMESTAMP,
                    "updated_at": bigquery.enums.SqlTypeNames.TIMESTAMP,
                }
                rows_to_insert.append(row)
            
            errors = self.client.insert_rows_json(
                self.client.get_table(table_id), rows_to_insert
            )
            
            if errors:
                logger.error(f"Failed to insert rows: {errors}")
                return False
            
            logger.info(f"Added {len(documents)} documents to table {collection_name}")
            return True
        except Exception as e:
            logger.error(f"Failed to add documents to {collection_name}: {e}")
            return False
    
    async def semantic_search(self, collection_name: str, query: str, limit: int = 10) -> List[Dict[str, Any]]:
        """Perform semantic search using BigQuery ML"""
        # Note: This would require BigQuery ML setup for embeddings
        # For now, implementing basic text search
        try:
            if not self.client:
                await self.connect()
            
            sql_query = f"""
            SELECT 
                issue_id,
                issue_title,
                issue_description,
                issue_categories,
                metadata
            FROM `{self.project_id}.{self.dataset_id}.{collection_name}`
            WHERE 
                LOWER(issue_title) LIKE LOWER('%{query}%') 
                OR LOWER(issue_description) LIKE LOWER('%{query}%')
            LIMIT {limit}
            """
            
            results = self.client.query(sql_query).result()
            
            formatted_results = []
            for row in results:
                result = {
                    'id': row['issue_id'],
                    'metadata': {
                        'issue_id': row['issue_id'],
                        'issue_title': row['issue_title'],
                        'issue_description': row['issue_description'],
                        'issue_categories': row['issue_categories'],
                    }
                }
                formatted_results.append(result)
            
            logger.info(f"Found {len(formatted_results)} results for query in {collection_name}")
            return formatted_results
        except Exception as e:
            logger.error(f"Failed to perform search in {collection_name}: {e}")
            return []
    
    async def get_document(self, collection_name: str, document_id: str) -> Optional[JiraDocument]:
        """Retrieve a specific document from BigQuery"""
        try:
            if not self.client:
                await self.connect()
            
            sql_query = f"""
            SELECT * FROM `{self.project_id}.{self.dataset_id}.{collection_name}`
            WHERE issue_id = '{document_id}'
            LIMIT 1
            """
            
            results = self.client.query(sql_query).result()
            
            for row in results:
                return JiraDocument(
                    issue_id=row['issue_id'],
                    issue_title=row['issue_title'],
                    issue_description=row['issue_description'],
                    issue_categories=row['issue_categories'],
                    metadata=json.loads(row['metadata']) if row['metadata'] else {},
                    embedding=row['embedding'] if row['embedding'] else None
                )
            
            return None
        except Exception as e:
            logger.error(f"Failed to get document {document_id} from {collection_name}: {e}")
            return None
    
    async def update_document(self, collection_name: str, document_id: str, document: JiraDocument) -> bool:
        """Update an existing document in BigQuery"""
        try:
            if not self.client:
                await self.connect()
            
            sql_query = f"""
            UPDATE `{self.project_id}.{self.dataset_id}.{collection_name}`
            SET 
                issue_title = '{document.issue_title}',
                issue_description = '{document.issue_description}',
                issue_categories = {document.issue_categories},
                metadata = '{json.dumps(document.metadata)}',
                updated_at = CURRENT_TIMESTAMP()
            WHERE issue_id = '{document_id}'
            """
            
            self.client.query(sql_query).result()
            logger.info(f"Updated document {document_id} in table {collection_name}")
            return True
        except Exception as e:
            logger.error(f"Failed to update document {document_id} in {collection_name}: {e}")
            return False
    
    async def delete_document(self, collection_name: str, document_id: str) -> bool:
        """Delete a document from BigQuery"""
        try:
            if not self.client:
                await self.connect()
            
            sql_query = f"""
            DELETE FROM `{self.project_id}.{self.dataset_id}.{collection_name}`
            WHERE issue_id = '{document_id}'
            """
            
            self.client.query(sql_query).result()
            logger.info(f"Deleted document {document_id} from table {collection_name}")
            return True
        except Exception as e:
            logger.error(f"Failed to delete document {document_id} from {collection_name}: {e}")
            return False