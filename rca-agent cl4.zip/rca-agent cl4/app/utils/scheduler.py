import asyncio
import logging
from typing import Callable, Dict, Any
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

class TaskScheduler:
    """Simple task scheduler for background tasks"""
    
    def __init__(self):
        self.tasks: Dict[str, Dict[str, Any]] = {}
        self.running = False
    
    def add_task(self, name: str, func: Callable, interval: int, *args, **kwargs):
        """Add a scheduled task"""
        self.tasks[name] = {
            "func": func,
            "interval": interval,
            "args": args,
            "kwargs": kwargs,
            "last_run": None,
            "next_run": datetime.now() + timedelta(seconds=interval)
        }
        logger.info(f"Added scheduled task: {name} (interval: {interval}s)")
    
    def remove_task(self, name: str):
        """Remove a scheduled task"""
        if name in self.tasks:
            del self.tasks[name]
            logger.info(f"Removed scheduled task: {name}")
    
    async def start(self):
        """Start the task scheduler"""
        if self.running:
            logger.warning("Task scheduler is already running")
            return
        
        self.running = True
        logger.info("Starting task scheduler")
        
        while self.running:
            try:
                now = datetime.now()
                
                for name, task in self.tasks.items():
                    if now >= task["next_run"]:
                        try:
                            logger.debug(f"Running scheduled task: {name}")
                            
                            if asyncio.iscoroutinefunction(task["func"]):
                                await task["func"](*task["args"], **task["kwargs"])
                            else:
                                task["func"](*task["args"], **task["kwargs"])
                            
                            task["last_run"] = now
                            task["next_run"] = now + timedelta(seconds=task["interval"])
                            
                        except Exception as e:
                            logger.error(f"Error running scheduled task {name}: {e}")
                
                await asyncio.sleep(1)  # Check every second
                
            except Exception as e:
                logger.error(f"Error in task scheduler loop: {e}")
                await asyncio.sleep(5)  # Wait before retrying
    
    def stop(self):
        """Stop the task scheduler"""
        self.running = False
        logger.info("Task scheduler stopped")
