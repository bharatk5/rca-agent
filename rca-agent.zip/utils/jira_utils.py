import requests
import logging
from typing import List, Dict, Optional
from pydantic_settings import BaseSettings

logger = logging.getLogger(__name__)
logging.basicConfig(level=logging.INFO)


class JiraConfig(BaseSettings):
    JIRA_BASE_URL: str
    JIRA_API_KEY: str
    JIRA_EMAIL: str  # Required by some setups for basic auth

    class Config:
        env_file = ".env"


class JiraClient:
    def __init__(self, config: JiraConfig):
        self.config = config
        self.session = requests.Session()
        self.session.headers.update({
            # Using Bearer token for Jira Cloud API tokens
            "Authorization": f"Bearer {self.config.JIRA_API_KEY}",
            "Accept": "application/json",
            "Content-Type": "application/json"
        })

    def get_issues(self, jql: str, max_results_per_page: int = 100) -> List[Dict]:
        """
        Fetches all issues from Jira matching the JQL query, handling pagination.
        """
        url = f"{self.config.JIRA_BASE_URL}/rest/api/2/search"
        all_issues = []
        start_at = 0
        
        while True:
            params = {
                "jql": jql,
                "maxResults": max_results_per_page,
                "startAt": start_at
            }
            try:
                response = self.session.get(url, params=params)
                response.raise_for_status()
                data = response.json()
                issues_on_page = data.get("issues", [])
                all_issues.extend(issues_on_page)

                if not issues_on_page or len(all_issues) >= data.get("total", 0):
                    break
                start_at += len(issues_on_page)
            except requests.RequestException as e:
                logger.error(f"Failed to fetch issues from Jira (page starting at {start_at})", exc_info=True)
                break # Stop on error

        logger.info(f"Fetched a total of {len(all_issues)} issues from Jira for JQL: {jql}")
        return all_issues

    def extract_issue_details(self, issue: Dict) -> Dict[str, Optional[str]]:
        try:
            key = issue.get("key")
            fields = issue.get("fields", {})
            title = fields.get("summary")
            description = fields.get("description")
            categories = fields.get("labels", [])  # Assuming categories are in labels
            return {
                "issue_id": key,
                "title": title,
                "description": description,
                "categories": categories
            }
        except Exception as e:
            logger.error(f"Failed to parse issue {issue.get('key')}", exc_info=True)
            return {}
