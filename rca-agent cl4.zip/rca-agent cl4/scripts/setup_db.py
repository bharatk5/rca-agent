import asyncio
import logging
import sys
import os
from pathlib import Path

# Add parent directory to path to import app modules
sys.path.append(str(Path(__file__).parent.parent))

from app.config import settings, DatabaseType
from app.database.chromadb_client import ChromaDBClient
from app.database.bigquery_client import BigQueryClient
from app.services.jira_service import JiraService
from app.services.llm_service import LLMService, LLMConfig, LLMProvider
from app.database.base import JiraDocument

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

async def setup_chromadb():
    """Setup ChromaDB database"""
    logger.info("Setting up ChromaDB...")
    
    client = ChromaDBClient(
        host=settings.chromadb_host,
        port=settings.chromadb_port,
        persist_directory=settings.chromadb_persist_directory
    )
    
    try:
        await client.connect()
        
        # Create main collection
        collection_created = await client.create_collection(settings.agent_collection_name)
        if collection_created:
            logger.info(f"Created collection: {settings.agent_collection_name}")
        else:
            logger.error(f"Failed to create collection: {settings.agent_collection_name}")
            return False
        
        await client.disconnect()
        logger.info("ChromaDB setup completed successfully")
        return True
        
    except Exception as e:
        logger.error(f"Failed to setup ChromaDB: {e}")
        return False

async def setup_bigquery():
    """Setup BigQuery database"""
    logger.info("Setting up BigQuery...")
    
    if not settings.bigquery_project_id:
        logger.error("BigQuery project ID not configured")
        return False
    
    client = BigQueryClient(
        project_id=settings.bigquery_project_id,
        dataset_id=settings.bigquery_dataset_id
    )
    
    try:
        await client.connect()
        
        # Create main table
        table_created = await client.create_collection(settings.agent_collection_name)
        if table_created:
            logger.info(f"Created table: {settings.agent_collection_name}")
        else:
            logger.error(f"Failed to create table: {settings.agent_collection_name}")
            return False
        
        await client.disconnect()
        logger.info("BigQuery setup completed successfully")
        return True
        
    except Exception as e:
        logger.error(f"Failed to setup BigQuery: {e}")
        return False

async def populate_initial_data():
    """Populate database with initial Jira stories"""
    logger.info("Populating database with initial data...")
    
    # Initialize services
    jira_service = JiraService(
        base_url=settings.jira_base_url,
        username=settings.jira_username,
        api_token=settings.jira_api_token
    )
    
    llm_config = LLMConfig(
        provider=LLMProvider(settings.llm_provider),
        model=settings.llm_model,
        api_key=settings.llm_api_key,
        base_url=settings.llm_base_url,
        temperature=settings.llm_temperature,
        max_tokens=settings.llm_max_tokens
    )
    llm_service = LLMService(llm_config)
    
    # Initialize database client
    if settings.database_type == DatabaseType.CHROMADB:
        database = ChromaDBClient(
            host=settings.chromadb_host,
            port=settings.chromadb_port,
            persist_directory=settings.chromadb_persist_directory
        )
    else:
        database = BigQueryClient(
            project_id=settings.bigquery_project_id,
            dataset_id=settings.bigquery_dataset_id
        )
    
    try:
        await database.connect()
        
        # Test Jira connection
        async with jira_service:
            if not await jira_service.test_connection():
                logger.error("Cannot connect to Jira. Check your credentials.")
                return False
            
            # Get story issues from Jira
            logger.info("Fetching stories from Jira...")
            stories = await jira_service.get_story_issues(limit=500)
            
            if not stories:
                logger.warning("No stories found in Jira")
                return True
            
            logger.info(f"Found {len(stories)} stories to process")
            
            # Convert to JiraDocument format and generate embeddings
            documents = []
            for i, story in enumerate(stories):
                logger.info(f"Processing story {i+1}/{len(stories)}: {story.key}")
                
                # Generate embedding for the story
                text_content = f"{story.title} {story.description}"
                embedding = await llm_service.generate_embedding(text_content)
                
                doc = JiraDocument(
                    issue_id=story.key,
                    issue_title=story.title,
                    issue_description=story.description,
                    issue_categories=story.labels + story.components,
                    metadata={
                        "status": story.status,
                        "priority": story.priority,
                        "assignee": story.assignee,
                        "reporter": story.reporter,
                        "created": story.created.isoformat(),
                        "updated": story.updated.isoformat(),
                        "issue_type": story.issue_type
                    },
                    embedding=embedding
                )
                documents.append(doc)
                
                # Process in batches to avoid memory issues
                if len(documents) >= 50:
                    success = await database.add_documents(settings.agent_collection_name, documents)
                    if success:
                        logger.info(f"Added batch of {len(documents)} documents")
                    else:
                        logger.error("Failed to add document batch")
                        return False
                    documents = []
            
            # Add remaining documents
            if documents:
                success = await database.add_documents(settings.agent_collection_name, documents)
                if success:
                    logger.info(f"Added final batch of {len(documents)} documents")
                else:
                    logger.error("Failed to add final document batch")
                    return False
            
            logger.info(f"Successfully populated database with {len(stories)} stories")
            return True
            
    except Exception as e:
        logger.error(f"Failed to populate initial data: {e}")
        return False
    finally:
        await database.disconnect()
        await llm_service.close()

async def main():
    """Main setup function"""
    logger.info("Starting RCA Agent database setup...")
    
    # Setup database
    if settings.database_type == DatabaseType.CHROMADB:
        success = await setup_chromadb()
    elif settings.database_type == DatabaseType.BIGQUERY:
        success = await setup_bigquery()
    else:
        logger.error(f"Unsupported database type: {settings.database_type}")
        sys.exit(1)
    
    if not success:
        logger.error("Database setup failed")
        sys.exit(1)
    
    # Populate with initial data
    populate_data = input("Would you like to populate the database with initial Jira stories? (y/N): ")
    if populate_data.lower() in ['y', 'yes']:
        success = await populate_initial_data()
        if not success:
            logger.error("Failed to populate initial data")
            sys.exit(1)
    
    logger.info("Database setup completed successfully!")

if __name__ == "__main__":
    asyncio.run(main())
