from fastapi import APIRouter, Depends, HTTPException, status, Request
from typing import List, Dict, Any
from datetime import timedelta

from ...models.api_models import (
    LoginRequest, TokenResponse, JiraIssueResponse, 
    CreateStoryRequest, UpdateStoryRequest
)
from ...core.security import (
    authenticate_user, create_access_token, require_read, require_write
)
from ...services.jira_service import JiraService, JiraStoryRequest

router = APIRouter()

@router.post("/auth/login", response_model=TokenResponse)
async def login(login_request: LoginRequest):
    """Authenticate user and return access token"""
    user = authenticate_user(login_request.username, login_request.password)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username or password",
            headers={"WWW-Authenticate": "Bearer"},
        )
    
    access_token_expires = timedelta(minutes=30)
    access_token = create_access_token(
        data={"sub": user["username"]}, 
        expires_delta=access_token_expires
    )
    
    return TokenResponse(access_token=access_token)

@router.get("/jira/issues/{issue_key}", response_model=JiraIssueResponse)
async def get_issue(
    issue_key: str,
    request: Request,
    current_user = Depends(require_read)
):
    """Get a specific Jira issue"""
    jira_service: JiraService = request.app.state.get_jira_service()
    
    async with jira_service:
        issue = await jira_service.get_issue(issue_key)
        
        if not issue:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Issue {issue_key} not found"
            )
        
        return JiraIssueResponse(
            id=issue.id,
            key=issue.key,
            title=issue.title,
            description=issue.description,
            status=issue.status,
            issue_type=issue.issue_type,
            priority=issue.priority,
            assignee=issue.assignee,
            reporter=issue.reporter,
            created=issue.created,
            updated=issue.updated,
            labels=issue.labels,
            components=issue.components
        )

@router.get("/jira/issues/search", response_model=List[JiraIssueResponse])
async def search_issues(
    jql: str,
    max_results: int = 50,
    request: Request,
    current_user = Depends(require_read)
):
    """Search Jira issues using JQL"""
    jira_service: JiraService = request.app.state.get_jira_service()
    
    async with jira_service:
        issues = await jira_service.search_issues(jql, max_results)
        
        return [
            JiraIssueResponse(
                id=issue.id,
                key=issue.key,
                title=issue.title,
                description=issue.description,
                status=issue.status,
                issue_type=issue.issue_type,
                priority=issue.priority,
                assignee=issue.assignee,
                reporter=issue.reporter,
                created=issue.created,
                updated=issue.updated,
                labels=issue.labels,
                components=issue.components
            )
            for issue in issues
        ]

@router.post("/jira/stories", response_model=Dict[str, str])
async def create_story(
    story_request: CreateStoryRequest,
    request: Request,
    current_user = Depends(require_write)
):
    """Create a new Jira story"""
    jira_service: JiraService = request.app.state.get_jira_service()
    
    jira_story_request = JiraStoryRequest(
        project_key=story_request.project_key,
        summary=story_request.summary,
        description=story_request.description,
        issue_type=story_request.issue_type,
        priority=story_request.priority,
        assignee=story_request.assignee,
        labels=story_request.labels,
        components=story_request.components,
        custom_fields=story_request.custom_fields
    )
    
    async with jira_service:
        issue_key = await jira_service.create_story(jira_story_request)
        
        if not issue_key:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Failed to create story"
            )
        
        return {"issue_key": issue_key, "message": "Story created successfully"}

@router.put("/jira/stories/{issue_key}", response_model=Dict[str, str])
async def update_story(
    issue_key: str,
    update_request: UpdateStoryRequest,
    request: Request,
    current_user = Depends(require_write)
):
    """Update an existing Jira story"""
    jira_service: JiraService = request.app.state.get_jira_service()
    
    # Convert to dictionary, excluding None values
    update_data = {
        k: v for k, v in update_request.dict().items() 
        if v is not None
    }
    
    if not update_data:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="No update data provided"
        )
    
    async with jira_service:
        success = await jira_service.update_story(issue_key, update_data)
        
        if not success:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Failed to update story {issue_key}"
            )
        
        return {"issue_key": issue_key, "message": "Story updated successfully"}

@router.delete("/jira/stories/{issue_key}", response_model=Dict[str, str])
async def delete_story(
    issue_key: str,
    request: Request,
    current_user = Depends(require_write)
):
    """Delete a Jira story"""
    jira_service: JiraService = request.app.state.get_jira_service()
    
    async with jira_service:
        success = await jira_service.delete_story(issue_key)
        
        if not success:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Failed to delete story {issue_key}"
            )
        
        return {"issue_key": issue_key, "message": "Story deleted successfully"}

@router.post("/jira/issues/{issue_key}/comment", response_model=Dict[str, str])
async def add_comment(
    issue_key: str,
    comment_text: str,
    request: Request,
    current_user = Depends(require_write)
):
    """Add a comment to a Jira issue"""
    jira_service: JiraService = request.app.state.get_jira_service()
    
    async with jira_service:
        success = await jira_service.add_comment(issue_key, comment_text)
        
        if not success:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Failed to add comment to issue {issue_key}"
            )
        
        return {"issue_key": issue_key, "message": "Comment added successfully"}