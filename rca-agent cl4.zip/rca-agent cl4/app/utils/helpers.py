import hashlib
import json
from typing import Any, Dict, List
from datetime import datetime

def generate_hash(data: str) -> str:
    """Generate MD5 hash of a string"""
    return hashlib.md5(data.encode()).hexdigest()

def safe_json_loads(data: str, default: Any = None) -> Any:
    """Safely load JSON data"""
    try:
        return json.loads(data)
    except (json.JSONDecodeError, TypeError):
        return default

def safe_json_dumps(data: Any, default: str = "{}") -> str:
    """Safely dump data to JSON"""
    try:
        return json.dumps(data, default=str)
    except (TypeError, ValueError):
        return default

def extract_text_content(text: str, max_length: int = 1000) -> str:
    """Extract and clean text content"""
    if not text:
        return ""
    
    # Remove extra whitespace and newlines
    cleaned = " ".join(text.split())
    
    # Truncate if too long
    if len(cleaned) > max_length:
        cleaned = cleaned[:max_length] + "..."
    
    return cleaned

def format_datetime(dt: datetime) -> str:
    """Format datetime to ISO string"""
    return dt.isoformat() if dt else ""

def parse_datetime(dt_str: str) -> datetime:
    """Parse datetime from ISO string"""
    try:
        return datetime.fromisoformat(dt_str.replace("Z", "+00:00"))
    except (ValueError, AttributeError):
        return datetime.now()

def chunk_list(lst: List[Any], chunk_size: int) -> List[List[Any]]:
    """Split list into chunks of specified size"""
    return [lst[i:i + chunk_size] for i in range(0, len(lst), chunk_size)]

def merge_dicts(dict1: Dict[str, Any], dict2: Dict[str, Any]) -> Dict[str, Any]:
    """Merge two dictionaries, with dict2 values taking precedence"""
    result = dict1.copy()
    result.update(dict2)
    return result

def validate_jira_key(key: str) -> bool:
    """Validate Jira issue key format"""
    import re
    pattern = r'^[A-Z][A-Z0-9_]*-\d+
    return bool(re.match(pattern, key))

def sanitize_string(text: str, max_length: int = 255) -> str:
    """Sanitize string for database storage"""
    if not text:
        return ""
    
    # Remove null bytes and control characters
    sanitized = ''.join(char for char in text if ord(char) >= 32 or char in '\n\r\t')
    
    # Truncate if too long
    if len(sanitized) > max_length:
        sanitized = sanitized[:max_length-3] + "..."
    
    return sanitized.strip()
