from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from datetime import datetime

class LoginRequest(BaseModel):
    username: str
    password: str

class TokenResponse(BaseModel):
    access_token: str
    token_type: str = "bearer"

class JiraIssueResponse(BaseModel):
    id: str
    key: str
    title: str
    description: str
    status: str
    issue_type: str
    priority: str
    assignee: Optional[str]
    reporter: str
    created: datetime
    updated: datetime
    labels: List[str]
    components: List[str]

class CreateStoryRequest(BaseModel):
    project_key: str
    summary: str
    description: str
    issue_type: str = "Story"
    priority: str = "Medium"
    assignee: Optional[str] = None
    labels: List[str] = []
    components: List[str] = []
    custom_fields: Dict[str, Any] = {}

class UpdateStoryRequest(BaseModel):
    summary: Optional[str] = None
    description: Optional[str] = None
    priority: Optional[str] = None
    assignee: Optional[str] = None
    labels: Optional[List[str]] = None
    components: Optional[List[str]] = None

class RCARequest(BaseModel):
    issue_key: str

class RCAResponse(BaseModel):
    bug_issue: JiraIssueResponse
    similar_issues: List[Dict[str, Any]]
    analysis: str
    confidence_score: float
    recommended_actions: List[str]
    created_at: datetime

class AgentStatusResponse(BaseModel):
    running: bool
    last_check: Optional[datetime]
    collection_name: str
    poll_interval: int

class SearchRequest(BaseModel):
    query: str
    limit: int = Field(default=10, ge=1, le=100)

class HealthResponse(BaseModel):
    status: str
    timestamp: datetime
    services: Dict[str, str]
